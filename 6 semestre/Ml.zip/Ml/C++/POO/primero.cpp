#include <iostream>
#include <list>

using namespace std;

class Estudiante
{
public:
    string Nombre;
    string Apellidos;
    int Asistencias;
    list<string> Materias;

    Estudiante(string nombre, string apellidos)
    {
        Nombre = nombre;
        Apellidos = apellidos;
        Asistencias = 0;

    }

    void getInfo()
    {
        cout<<"Nombre: "<<Nombre<<endl;
        cout<<"Apellido: "<<Apellidos<<endl;
        cout<<"Asistencias: "<<Asistencias<<endl;
        for (string materia: Materias)
        {
            cout<<materia<<endl;
        }
    }
};

int main()
{

    Estudiante estudiante01("Juan","Castro");
    estudiante01.Materias.push_back("Fisica Cuantica");
    estudiante01.Materias.push_back("Inteligencia Artificial");
    estudiante01.Materias.push_back("Modelacion");
    estudiante01.getInfo();

    /*

        Estudiante estudiante01("Juan","Castro");
        cout<<"Nombre: "<<estudiante01.Nombre<<endl;
        cout<<"Apellido: "<<estudiante01.Apellidos<<endl;
        cout<<"Las asistencias son: "<<estudiante01.Asistencias<<endl;
        cout<<"INgresp de materias: ";
        estudiante01.Materias.push_back("Fisica Cuantica");
        estudiante01.Materias.push_back("Inteligencia Artificial");
        estudiante01.Materias.push_back("Modelacion");
        for (string materia: estudiante01.Materias){
            cout<<materia<<endl;
        }




    */

    /*estudiante01.nombre = "Juan Carlos";
    estudiante01.apellidos = "Castro";
    estudiante01.asistencias = 1000;
    estudiante01.materias = {"Fundamentos 02", "Fisica Cuantica", "Patrones de Dise�o"};

    cout<<"Nombre: "<<estudiante01.nombre<<endl;
    cout<<"Apellido: "<<estudiante01.apellidos<<endl;
    cout<<"Las asistencias son: "<<estudiante01.asistencias<<endl;
    cout<<"materias: ";
    for (string materia: estudiante01.materias){
        cout<<materia<<endl;
    }


    Estudiante estudiante01;
    estudiante02.nombre = "Pedro";
    estudiante02.apellidos = "Perez";
    estudiante02.asistencias = 997;
    estudiante02.materias = {"Fisiza", "Fisica Cuantica", "Metamorfois"};
    */



    return 0;
    system("Pause>0");
}
