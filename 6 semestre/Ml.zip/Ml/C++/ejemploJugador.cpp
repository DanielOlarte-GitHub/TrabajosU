# include <iostream>
using namespace std;

struct Vector{
	float x,y,z; //x,y,z elementos de tipo float
};

struct Jugador{
	string nombre;
	int edad;
	Vector posicion;
	
	
};

int main(){
		
	Jugador miJugador;
	
	cout<<"Ingrese la edad del jugador"<<endl;
	cin>>miJugador.edad;
	cout<<"Ingrese el nombre del jugador"<<endl;
	cin>>miJugador.nombre;
	cout<<"Ingrese la posicion X del jugador"<<endl;
	cin>>miJugador.posicion.x;
	cout<<"Ingrese la posicion Y del jugador"<<endl;
	cin>>miJugador.posicion.y;
	cout<<"Ingrese la posicion Z del jugador"<<endl;
	cin>>miJugador.posicion.z;
	
	cout<<"La edad del jugador es: "<<miJugador.edad<<endl;
	cout<<"El nombre del jugador es: "<<miJugador.nombre<<endl;
	cout<<"La posicion de x del jugador es: "<<miJugador.posicion.x<<endl;
	cout<<"La posicion de y del jugador es: "<<miJugador.posicion.y<<endl;
	cout<<"La posicion de z del jugador es: "<<miJugador.posicion.z<<endl;
	
	
	
	system("pause>0");
}
