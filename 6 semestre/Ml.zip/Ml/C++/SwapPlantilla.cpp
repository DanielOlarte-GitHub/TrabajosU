//Realizar una funcion que haga un SWAPPING entre 2 variables
#include <iostream>
using namespace std;

template<typename T>

void Swap(T &a, T &b){
	T aux=a;
	a=b;
	b=aux;
	
}

void Swap(int &a, int &b){
	int aux=a;
	a=b;
	b=aux;
	
}

int main(){
	char x = '+', y = '*';
	cout<<"Antes del cambio: x="<<x<<"   y="<<y<<endl;
	Swap(x,y);
	cout<<"Despues del cambio: x="<<x<<"   y="<<y<<endl;
	
	
	int num = 4, num2 = 7;
	cout<<"Antes del cambio: x="<<num<<"   y="<<num2<<endl;
	swap(num,num2);
	cout<<"Despues del cambio: x="<<num<<"   y="<<num2<<endl;
	
	system("pause>0");
}
