#include <iostream>

using namespace std;
// Dado una entrada del entero de un usuario decir si es par o impar

int main(){
	
	int numero;
	
	cout<<"Digite el numero que desea"<<endl;
	cin>>numero;
	
	if(numero%2==0){
		cout<<"El numero que usted ingreso es un numero par"<<endl;
	}else{
		cout<<"El numero que usted ingreso es un numero impar"<<endl;
	}
	
	cout<<"Fin del programa"<<endl;
	
	system("pause>0");
}
