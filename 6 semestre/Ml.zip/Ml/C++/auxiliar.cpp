//Se tienen 2 variables y se quiere intercambiar el valor de las variables
//SWAPPING

#include <iostream>

using namespace std;

int main(){
	int a=40,b=70;
	int aux = a;
	a=b;
	b = aux;
	/
	cout<<aux<<endl;
}

