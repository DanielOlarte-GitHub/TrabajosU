#include <iostream>
using namespace std;

int main(){
	int pin, adivinePin;
	
	cout<<"INGRESE EL PIN VERDADERO"<<endl;
	cin>>pin;
	
	system("cls");
	
	cout<<"ADIVINE EL PIN INGRESADO"<<endl;
	cin>>adivinePin;
	
	/*if(adivinePin == pin){
		cout<<"Adivino"<<endl;
	}else{
		cout<<"No adivino"<<endl;
	}*/
	
	(pin==adivinePin)? cout<<"Correcto": cout<<"Incorrecto"<<endl;
	
	system("pause>0");
}
