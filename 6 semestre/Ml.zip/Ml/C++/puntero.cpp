# include <iostream>
using namespace std;

int main(){
	
	int variable = 25;
	int * miPuntero;
	miPuntero = &variable;
	*miPuntero = 40;
	
	cout<<"El valor de mi variable es: "<<variable<<endl;
	
	system("pause>0");
}
