#include <iostream>
using namespace std;


int tiradas(int dados[], int valorSuperar, int suma, int tirada){
    if( tirada==sizeof(dados)/sizeof(*dados) && suma>= valorSuperar){
        for(int i = 0; i <sizeof(dados)/sizeof(*dados) ; i++){
            if(i==sizeof(dados)/sizeof(*dados)-1){
            	cout<<dados[i]<<" = ";
            }else{
            	cout<<dados[i]<<" + ";
        	} 
    	}
    	cout<<suma<<endl;
	}else if(tirada!=sizeof(dados)/sizeof(*dados)){
		for (int i = 1; i <= 6; i++) {
            dados[tirada] = i;
            suma+=i;
            tiradas(dados, valorSuperar, suma, (tirada+1));
            suma-=i;
        }
	}
	
}

int main(){
	
	int dados[3];
	int valorSuperar;
	cout<<"Digite el valor a superar"<<endl;
	cin>>valorSuperar;
	
	tiradas(dados, valorSuperar, 0, 0);
}
