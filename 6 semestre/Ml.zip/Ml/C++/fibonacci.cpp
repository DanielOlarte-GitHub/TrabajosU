#include<iostream>
using namespace std ;

int serieFibo(int pos){
	if(pos==1 || pos ==2){
		return 1;
	}else if(pos==0){
		return 0;
	}
	return serieFibo(pos-1) + serieFibo(pos-2);
}

int main(){
	int num;
	cout<<"\n\n\t\tIngrese de que tama�o quiere ver la serie fibonacci\n"<<endl;
	cin>>num;
	
	for(int i = 0; i<=num; i++){
		cout<<"  "<<serieFibo(i);
	}
}
