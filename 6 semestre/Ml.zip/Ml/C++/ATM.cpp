//Realizar una funcion que me presente balance actual, deposito, retiro y salida como un cajero automatico
#include <iostream>

using namespace std;

void leerMenu(){
	cout<<"****ATM****\n"<<endl;
	cout<<"1) Balance Actual"<<endl;
	cout<<"2) Depositar"<<endl;
	cout<<"3) Retirar"<<endl;
	cout<<"4) Salir"<<endl;
}

int main(){
	int opcion;
	double balance = 50000, depRet;
	do{
		leerMenu;
		cin>>opcion;
	
		switch(opcion){
			case 1:
				cout<<"Balance Actual: "<<balance<<" $"<<endl;
				system("pause");
				system("cls");
			break;	
			
			case 2:
				cout<<"Ingrese cuando desea depostar"<<endl;
				cin>>depRet;
				balance+=depRet;
				cout<<"\nValor depositado con exito"<<endl;
				system("pause")
				system("cls")
			break;	
			
			case 3:
				cout<<"Ingrese cuando desea retirar"<<endl;
				cin>>depRet;
				balance-=depRet;
				cout<<"\nValor retirado con exito"<<endl;
				system("pause");
				system("cls");
			break;
			
			default:
				cout<<"\nDIGITO UN VALOR INVALIDO, INTENTE DE NUEVO"<<endl;
				system("pause");
				system("cls");
			break;	
		}
	}
	
	
	
	
	system("pause>0");
}
