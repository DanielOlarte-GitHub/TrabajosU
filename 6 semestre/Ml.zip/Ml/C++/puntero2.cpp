# include <iostream>
using namespace std;

int main(){
	
	int valor1 = 5;
	int valor2 = 15;
	int * puntero1, * puntero2;
	
	puntero1 = &valor1; //Puntero 1 direccion del valor 1
	puntero2 = &valor2; //Puntero 2 direccion del valor 2
	
	*puntero1 = 10; //El valor apuntado por el puntero 1 es igual a 10
	*puntero2 = *puntero1; //El valor apuntado por el puntero 2 apunta al puntero 1
	
	puntero1 = puntero2; //El puntero 1 es igual al puntero 2 (El valor del puntero es copiado)
	
	*puntero1 = 40; //El valor apuntado por el puntero 1 es igual a 40
	
	cout<<"El primer valor es: "<<valor1<<endl;
	cout<<"El segundo valor es: "<<valor2<<endl;
	
	system("pause>0");
}
