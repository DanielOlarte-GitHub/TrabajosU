//Realizar un ejercicio que dada la altura y longitud, pintar la mitad de un triangulo equilatero
//altura 5,      longitud 5,       simbolo *
//	*
//  **
//	***
//	****
//	*****

#include <iostream>

using namespace std;
int main(){
	int altura, longitud;
	char simbolo;
	
	cout<<"DIGITE LA ALTURA"<<endl;
	cin>>altura;
	cout<<"DIGITE EL SIMBOLO"<<endl;
	cin>>simbolo;
	
	for(int i = 0; i < altura; i++){
		for(int j = 0; j < i; j++){
			cout<<simbolo;
		}
		cout<<endl;
	}
	system("pause>0");
}
