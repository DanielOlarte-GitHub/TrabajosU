# include <iostream>
using namespace std;

int main(){
	float consumoWattsAnual;
	cout<<"Ingrese el consumo de Watts Anual"
	cin>>consumoWattsAnual;
	float consumoWattsMensual = consumoWattsAnual/12;
	
	cout<<"El conusmo mensual de Watts sera: "<<consumoWattsMensual<<endl;
	system("pause>0");
}

