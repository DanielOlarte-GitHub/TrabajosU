# include <iostream>
using namespace std;

//Inicio de la definicion del objeto: Vector
struct Vector{
	float x,y,z; //x,y,z elementos de tipo float
};

int main(){
	
	Vector miVector; // Se instancia un Vector llamado miVector
	miVector.x = 20;
	miVector.y = 15;
	miVector.z = 4;
	
	cout<<"El vector de 3 dimensiones es: "<<miVector.x<<", "<<miVector.y<<", "<<miVector.z<<endl;
	
	system("pause>0");
}
