#include <iostream>
using namespace std;

/*
	Se requiere calcular el Indice de Masa Corporal (IMC)
	Delgadez extrema < 18.5
	Peso Normal entre 18.5 y 24.9
	Sobre peso >25
	IMC = Peso(Kg) / (Altura (m) **2)
	
*/

int main (){
	float peso, altura, imc;
	
	cout<<"Ingrese el Peso"<<endl;
	cin>>peso;
	
	cout<<"Ingrese la altura"<<endl;
	cin>>altura;

	imc = peso/(altura*altura);
	cout<<"El IMC es: "<<imc<<endl;
	
	if(imc<18.8){
		cout<<"Delgadez extrema"<<endl;
	}else{
		if(imc>25){
			cout<<"Sobre peso"<<endl;
		}else{
			cout<<"Peso Normal"<<endl;
		}
	}
	
	system("pause>0");
	
}
