#include <iostream>

using namespace std;

int main(){
	cout<<5+2<<endl;
	cout<<5/2<<endl;
	cout<<5%2<<endl;
	
	
	//CONTADORES
	
	int contador = 9;
	contador++;
	cout<<contador<<endl;
	
	contador--;
	cout<<contador<<endl;
	
	cout<<contador++<<endl;
	cout<<contador<<endl;
	
	int contador2 = 7;
	cout<<contador2++<<endl;
	cout<<contador2--<<endl;
	cout<<contador2<<endl;
	
	system("cls");
	
	int a = 5, b=5;
	cout<<(a=!b)<<endl;
	
	
	system("pause>0");
}
