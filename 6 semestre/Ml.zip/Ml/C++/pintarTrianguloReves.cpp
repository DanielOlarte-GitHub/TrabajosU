#include <iostream>
using namespace std;
int main(){
	int altura, longitud;
	char simbolo;
	
	cout<<"DIGITE LA ALTURA"<<endl;
	cin>>altura;
	cout<<"DIGITE EL SIMBOLO"<<endl;
	cin>>simbolo;
	
	for(int i = altura; i > 0; i--){
		for(int j = 0; j < i; j++){
			cout<<simbolo;
		}
		cout<<endl;
	}
	system("pause>0");
}
