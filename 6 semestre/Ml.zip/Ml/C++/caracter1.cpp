#include <iostream>

using namespace std;

int main(){
	
	char c1, c2, c3, c4, c5;
	
	cout<<"Introduzca 5 caracteres"<<endl;
	cin>>c1>>c2>>c3>>c4>>c5;
	
	cout<<"ASCII: "<<(int)c1<<endl;
	cout<<"ASCII: "<<(int)c2<<endl;
	cout<<"ASCII: "<<(int)c3<<endl;
	cout<<"ASCII: "<<(int)c4<<endl;
	cout<<"ASCII: "<<(int)c5<<endl;
	
	
	cout<< (int)'a'<<endl;
	cout<< int('a')<<endl;
	cout<< (int)'A'<<endl;
	cout<< (char)65<<endl;
	
	system("pause>0");
}
