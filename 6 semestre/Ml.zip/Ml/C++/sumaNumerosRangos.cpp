//Realizar una aplicacion que sume los numeros entre n y m
#include <iostream>
using namespace std;

int recursivaSum(int m, int n){
	if(m==n){
		return m;
	}
	return m+recursivaSum(m+1, n);
}

int main(){
	int num1 = 2, num2 = 4, suma=0;
	
	cout<<"Ingrese el numero m"<<endl;
	cin>>num1;
	cout<<"Ingrese el numero n"<<endl;
	cin>>num2;
	
	for(int i=num1; i<=num2; num1++){
		suma+=i;
	}
	cout<<"La suma es: "<<suma;
}
