//Calculadora
#include <iostream>
using namespace std;

int main(){
	float num1, num2, resultado;
	char operacion;
	cout<<"\tCALCULADORA\n"<<endl;
	
	cout<<"Ingrese un numero operacion y numero"<<endl;
	cin>>num1>>operacion>>num2;
	
	switch(operacion){
		case '+':
				cout<<num1<<operacion<<num2<<" = "<<num1 + num2;
		break;	
		
		case '-':
			cout<<num1<<operacion<<num2<<" = "<<num1 - num2;
		break;	
		
		case '*':
			cout<<num1<<operacion<<num2<<" = "<<num1 * num2;
		break;	
		
		case '/':
			cout<<num1<<operacion<<num2<<" = "<<num1 / num2;
		break;	
		
		case '%':
			cout<<num1<<operacion<<num2<<" = "<<(int)num1 % (int)num2;
		break;	
			
	}
	
	system("pause>0");
}
