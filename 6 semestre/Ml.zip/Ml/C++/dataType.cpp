# include <iostream>
using namespace std;

int main(){
	int anioDeNacimiento = 2020;
	char genero = 'F';
	bool adulto = true;
	float calificacion = 4.9;
	double ahorros = 3456789876543;
	
	cout<<"Capacidad de un int es: "<<sizeof(int)<<" bytes\n";
	//-1,-2,-3........,-2147483648
	cout<<"El minimo valor de int es: "<<INT_MIN<<endl;
	
	cout<<"El mayor valor de int es: "<<INT_MAX<<endl;
	
	cout<<"Capacidad de un char es: "<<sizeof(char)<<" bytes\n";
	
	cout<<"Capacidad de un bool es: "<<sizeof(bool)<<" bytes\n";
	
	cout<<"Capacidad de un float es: "<<sizeof(float)<<" bytes\n";
	
	cout<<"Capacidad de un double es: "<<sizeof(double)<<" bytes\n";
	
	system("pause>0");
}
