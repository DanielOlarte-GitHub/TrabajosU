//Realizar un programa
#include <iostream>
using namespace std;

int main(){
	int num;
	bool primoBandera = true;
	cout<<"Digite el numero que desee revisar"<<endl;
	cin>>num;
	
	for(int i = 2; i<num; i++){
		if(num% i == 0){
			primoBandera=false;
			break;
		}
	}
	
	
	if(primoBandera){
		cout<<"ES PRIMO EL NUMERO: "<<num;
	}else{
		cout<<"NO ES PRIMO"<<endl;
	}
	system("pause>0");
}
