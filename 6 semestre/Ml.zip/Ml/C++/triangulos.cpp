#include <iostream>

using namespace std;

//Dada la longitud de los lados de un triangulo (a,b,c) determinar si el triangulo es equilatero isosceles o escaleno

int main(){
	
	float a ,b ,c;
	
	cout<<"Ingrese los valores de los lados del triangulo"<<endl;
	
	cout<<"Lado 1: "<<endl;
	cin>>a;
	
	cout<<"Lado 2: "<<endl;
	cin>>b;
	
	cout<<"Lado 3: "<<endl;
	cin>>c;
	
	if(a==b && b==c){
		cout<<"Es un triangulo equilatero"<<endl;
	}else{
		if(a!=b && b!=c && a!=c){
			cout<<"Es un triangulo escaleno"<<endl;
		}else{
			cout<<"Es un triangulo isosceles";
		}
		
	}
	
}
