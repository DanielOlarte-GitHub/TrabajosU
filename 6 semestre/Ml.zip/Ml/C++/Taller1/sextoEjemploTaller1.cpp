#include <iostream>
using namespace std;
int rangoA, rangoB;

void pedir(){
	cout<<"DIGITE EL NUMERO DEL RANGO A"<<endl;
	cin>>rangoA;
	
	cout<<"DIGITE EL NUMERO DEL RANGO B"<<endl;
	cin>>rangoB;
}
int main(){
	bool pasa = true;
	int suma = 0;
	pedir();
	while(pasa){
		if(rangoA < 0 || rangoB<=0){
			pedir();
		}else{
			if(rangoA > rangoB){
				pedir();
			}else{
				pasa=false;
			}
		}
	}
	system("cls");
	while(rangoA<=rangoB){
		if(rangoA%5 == 0){
			suma += rangoA;
			printf("El numero %d es multiplo de 5\n", rangoA);
		}
		rangoA++;
	}
	
	printf("\n\nLa suma es: %d",suma);
}
