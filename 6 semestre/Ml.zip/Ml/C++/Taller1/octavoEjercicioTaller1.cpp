#include <iostream>

using namespace std;

void comprobar(int lista[],int sumIz,int sumDer,int finRango)
{
	int c1, c2;
	sumDer++;
 
    c1 = sumIz+1;
 
 	c2 = finRango-sumDer-1;
    
    if((c1-c2)==0)
    {
        printf("\t\tCentro Numerico: %i\n", lista[c1]);
    }
 
}
 
void centro(int finRango)
{
    
    int izquierda[finRango],derecha[finRango],lista[finRango];
    for(int i=0;i<finRango;i++) //inicializar los arreglos en 0
    {
        izquierda[i]=0;
        derecha[i]=0;
    }//288
    
    for(int i=0;i<finRango+1;i++){ //se llena la lista del 0 al i
		lista[i]=i;
	} 
        
    
    izquierda[1] = izquierda[0] + lista[1] + lista[1+1]; //suma de los primeros numeros de la izquierda
 
    derecha[1] = derecha[0] + lista[finRango] + lista[finRango-1]; //suma de los primeros numeros de la derecha
    
    for(int i=2;i<finRango;i++){ //insertar el resto de valores de elementos por la izquierda y derecha
    
        izquierda[i] = izquierda[i-1] + lista[i+1];
        derecha[i] = derecha[i-1] + lista[finRango-i];
    }
 
    for(int i=1;i<finRango;i++){ 
        for(int j=1;j<finRango;j++){
		
            if(izquierda[i] == derecha[j])//Si es el mismo numero la suma de la izquierda y la derecha se manda a comparar
                comprobar(lista,i,j,finRango);
        }
    }
}
 
int main(){
    int finRango;
 
 	cout<<"\t\tIntroduce el numero n:\n\t\t";
 	cin>>finRango;
 
    printf("\n\t\tLos numeros centrados del 1 al %i son:\n\n",finRango);
    
    for(int i=finRango; i>1; i--){
        centro(finRango);
        finRango--;
	}
}
