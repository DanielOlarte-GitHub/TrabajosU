#include <iostream>

using namespace std;

int main(){
	int x = 1, y = 1;
	
	if (x == y * 5){
		x = 0;
	}else{
		x = -1;
	}
	
	printf("El valor de X es: %d\n", x);
}


