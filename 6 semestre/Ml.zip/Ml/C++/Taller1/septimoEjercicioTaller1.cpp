#include <iostream>
using namespace std;

int main(){
	int dia, mes, ano, primero = 0, segundo = 0, tercero = 0;
	cout<<"DIGITE EL DIA SE SU NACIMIENTO"<<endl;
	cin>>dia;
	cout<<"DIGITE EL NUMERO DE MES SE SU NACIMIENTO"<<endl;
	cin>>mes;
	cout<<"DIGITE EL ANO SE SU NACIMIENTO"<<endl;
	cin>>ano;
	
	primero = dia+mes+ano;
	printf("\nLa suma es: %d \n\n", primero);
	
	while(primero>0){
		cout<<(primero%10)<<endl;
		segundo+=(primero%10);
		primero /= 10;
		
	}
	printf("\nLa suma es: %d \n\n", segundo);
	
	if(segundo>9){
		while(segundo>0){
			cout<<(segundo%10)<<endl;
			tercero+=(segundo%10);
			segundo /= 10;
		}
		printf("\nLa suma es: %d \n\n", tercero);
		printf("\nEL NUMERO DE TAROT ES: %d", tercero);
	}else{
		printf("\nEL NUMERO DE TAROT ES: %d", segundo);
	}
	
}
