#include <stdio.h>
using namespace std;

void fnx(int x){
	if(x){
		printf("El resultado de X es: %d\n",x);
	}
}

main(){
	int i, a = 1234;
	for(i = 0; i < 4; i++){
		fnx(a = a/10);
	}
}
