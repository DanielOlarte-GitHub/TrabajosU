#include <iostream>
using namespace std;

void camionOp(){
	int importe, km, tn;
	system("cls");
	cout<<"\n\t\t\tCAMION\n\n"<<endl;
	
	cout<<"\tDigite los km recorridos: ";
	cin>>km;
	
	cout<<"\n\tDigite las Tn del camion: ";
	cin>>tn;
	
	importe = (km*30) + (tn * 25);
	
	cout<<"\n\tIMPORTE: "<<importe;
	system("pause>0");
	system("cls");
}

void cocheOp(){
	int importe, km;
	system("cls");
	cout<<"\n\t\t\tCOCHE\n\n"<<endl;
	
	cout<<"\tDigite los km recorridos: ";
	cin>>km;
	
	importe = km*30;
	
	cout<<"\n\tIMPORTE: "<<importe;
	system("pause>0");
	system("cls");
}

void motoOp(){
	int importe, km;
	system("cls");
	cout<<"\n\t\t\tMOTO\n\n"<<endl;
	
	cout<<"\tDigite los km recorridos: ";
	cin>>km;
	
	importe = km*30;
	
	cout<<"\n\tIMPORTE: "<<importe;
	system("pause>0");
	system("cls");
}

void bicicletasOp(){
	int importe = 100;
	system("cls");
	cout<<"\n\t\t\tBICICLETA\n\n"<<endl;
	cout<<"\n\tIMPORTE: "<<importe;
	system("pause>0");
	system("cls");
}

void menu(){
	int men;
	cout<<"\t\t\tMENU:\n"<<endl;
	cout<<"\t1) Bicicleta"<<endl;
	cout<<"\t2) Moto"<<endl;
	cout<<"\t3) Coche"<<endl;
	cout<<"\t4) Camion"<<endl;
	cout<<"\t5) Salir\n"<<endl;
	cout<<"\tSeleccione la opcion deseada: ";
	cin>>men;
	
	switch(men){
		case 1:
			bicicletasOp();
		break;
		
		case 2:
			motoOp();
		break;
		
		case 3:
			cocheOp();
		break;
		
		case 4:
			camionOp();
		break;
		
		case 5:
			exit(0);
		break;
		
		default:
			cout<<"\n\n\t\t\tDIGITO UN VALOR INCORRECTO, VUELVA A INTENTARLO"<<endl;
		break;	
	}
	menu();
}
int main(){
	menu();
	system("pause>0");
}
