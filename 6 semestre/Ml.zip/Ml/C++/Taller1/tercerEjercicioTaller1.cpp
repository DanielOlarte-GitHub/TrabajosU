#include <stdio.h>
using namespace std;

int main(){
	int x = 0;
	for(x = 'a'; x <= 'z'; x +=10){
		printf("El resultado de X es: %c \n", x);
	}
}
