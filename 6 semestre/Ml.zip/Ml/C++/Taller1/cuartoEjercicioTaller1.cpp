#include <stdio.h>
using namespace std;

int main(){
	int x = 0, y = 0;
	for(x=6; x>0; x-=2){
		for(y=0; y<2; y++){
			printf("El resultado es: %d \n", x-y);
		}
	}
}
