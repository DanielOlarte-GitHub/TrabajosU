#include <stdio.h>
using namespace std;

int main(){
	int x = 1, y = 1;
	
	if(x == 1){
		if(y == 0){
			x = 10;
		}
	}else{
		x = -1;
	}
	
	printf("El resultado de X es: %d\n",x);
}
