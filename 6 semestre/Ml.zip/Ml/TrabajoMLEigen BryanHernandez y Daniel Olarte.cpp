/*
  Fecha Entrega: 07/09/2021
  Materia: Fundamentos Machine Learning Computacion Avanzada
  Profesor: John Corredor

  Integrantes:
	-Bryan Hernandez Pineda
	-Daniel Olarte Ávila
*/

#include <iostream>
#include <Eigen/Dense>

Eigen::Matrix<float, 3, 3> matriz;
Eigen::Matrix<float, 3, 3> matriz1;
Eigen::Matrix<float, 2, 3> matriz2;
Eigen::Matrix<float, 2, 3> matriz3;
Eigen::Matrix<float, 3, 2> matriz4;
Eigen::Matrix<float, 3, 4> matriz5;
Eigen::Matrix<float, 2, 2> matriz6;
Eigen::Matrix<float, 2, 2> matriz7;
Eigen::Matrix<float, 2, 2> matriz8;
Eigen::Matrix<float, 2, 2> matrizI;
Eigen::Matrix<float, 2, 2> matrizInversa;
Eigen::Matrix<float, 2, 2> matrizAux;
Eigen::Vector3f vector;
Eigen::Vector3f x;

//NOVENO PUNTO
void sistemaEcuacion() {
	std::cout << "\nResolver el siguiente sistema de ecuaciones: " << std::endl;
	std::cout << "\nx + y + z = 6\nx + 2y+ 5z = 12\nx + 4y + 25z = 36\n" << std::endl;
	matriz1 << 1, 1, 1,
		1, 2, 5,
		1, 4, 25;
	vector << 6, 12, 36;
	std::cout << "Matriz :\n\n" << matriz1 << std::endl;
	std::cout << "\nVector:\n\n" << vector << std::endl;
	x = matriz1.colPivHouseholderQr().solve(vector);
	std::cout << "\nLa solucion es:\n\n" << x << std::endl;
}

//OCTAVO PUNTO
void ecuacionIncognita() {
	//MATRIZ A
	matriz6 << 1, 1, 
		3, 4;
	//MATRIZ B
	matriz7 << 2, 1, 
		1, 1;
	//MATRIZ C
	matriz8 << 1, 2, 
		1, 3;
	//MATRIZ INCOGNITA
	matrizI << 1, 0, 
		0, 1;

	std::cout << "\nMatriz A: \n" << matriz6 << std::endl;
	std::cout << "\nMatriz B: \n" << matriz6 << std::endl;
	std::cout << "\nMatriz C: \n" << matriz6 << std::endl;
	std::cout << "\nCalcular el valor de X en las siguientes ecuaciones:" << std::endl;
	matrizInversa = matriz6.inverse();
	std::cout << "\nXA = B + I : \n" << (matriz7 + matrizI) * matrizInversa << std::endl;
	std::cout << "\nAX + B = C : \n" << matrizInversa * (matriz8 - matriz7) << std::endl;
	std::cout << "\nXA + B = 2C : \n" << (2 * matriz8 - matriz7) * matrizInversa << std::endl;
	matrizAux = matriz6 + matriz7;
	matrizInversa = matrizAux.inverse();
	std::cout << "\nAX + BX = C : \n" << (matrizInversa)*matriz8 << std::endl;
	matrizAux = (matriz6 * matriz7) - matriz8;
	matrizInversa = matrizAux.inverse();
	std::cout << "\nXAB -XC = 2C : \n" << 2 * matriz8 * matrizInversa << std::endl;
}

//SEPTIMO PUNTO
void rangoMatriz() {
	matriz5 << 2, -1, 0, 7,
		1, 0, 1, 3,
		3, 2, 7, 7;

	std::cout << "\nMatriz: \n" << matriz5 << std::endl;
	std::cout << "\nRango de la matriz: " << matriz5.colPivHouseholderQr().rank() << std::endl;
}

//SEXTO PUNTO
void analisisProblemas() {
	matriz2 << 400, 200, 50,
		300, 100, 30;
	matriz4 << 25, 1,
		30, 1.2,
		33, 1.3;

	std::cout << "Matriz de producciÃ³n:\n\n Filas: Modelos A, B;        Columnas:  Terminaciones N, L, S \n\n" << matriz2 << std::endl;
	std::cout << "\nMatriz de coste en horas:\n\n Filas:  Terminaciones N, L, S;    Columnas:  Coste en horas: T, A\n\n" << matriz4 << std::endl;
	std::cout << "\nMatriz que expresa las horas de taller y de administraciÃ³n para cada uno de los modelos:\n\n " << matriz2 * matriz4 << std::endl;
}

//QUINTO PUNTO
void sistemaEcuaciones() {
	matriz2 << 1, 2, 2,
		-2, 1, 0;

	matriz3 << -4, -3, -2,
		-1, 0, -1;

	std::cout << "matriz2: \n" << matriz2 << std::endl;
	std::cout << "matriz3: \n" << matriz2 << std::endl;
	std::cout << "\nsistema de ecuaciones: 2A+B = matriz2" << std::endl;
	std::cout << "\nsistema de ecuaciones: A-3B = matriz3" << std::endl;
	//SOLUCION B:
	std::cout << "multiplicamos la segunda ecuacion por -2" << std::endl;
	matriz3 = matriz3 * -2;
	std::cout << "matriz2: \n" << matriz2 << std::endl;
	std::cout << "matriz3: \n" << matriz2 << std::endl;
	std::cout << "\nsistema de ecuaciones: 2A+B = matriz2" << std::endl;
	std::cout << "\nsistema de ecuaciones: A-3B = matriz3" << std::endl;

	std::cout << "\nsumamos las ecuaciones y dividimos entre 7 para despejar\n\nB :\n\n";
	matriz3 = matriz3 + matriz2;
	matriz3 = matriz3 / 7;
	std::cout << matriz3 << std::endl;
	//SOLUCION A:
	matriz2 << 1, 2, 2,
		-2, 1, 0;
	matriz3 << -4, -3, -2,
		-1, 0, -1;
	std::cout << "\nSi multiplicamos la primera ecuaciÃ³n por 3 y sumando miembro a miembro obtenemos la solucion para A:\n\n";
	matriz2 = matriz2 * 3;
	matriz2 = matriz2 + matriz3;
	matriz2 = matriz2 / 7;
	std::cout << matriz2 << std::endl;
}

//CUARTO PUNTO
void matrizInv() {
	matriz << 1, -1, 0,
		0, 1, 0,
		2, 0, 1;

	std::cout << "\nMatriz inicial: \n" << matriz << std::endl;
	matriz1 = matriz.inverse();
	std::cout << "\nMatriz inversa: \n" << matriz1 << std::endl;
}

//TERCERO PUNTO
void nEsima() {
	matriz << 1, 0, 1,
		0, 1, 0,
		0, 0, 1;
	matriz1 = matriz;
	std::cout << "\nMatriz inicial: \n" << matriz << std::endl;
	int potencia;
	std::cout << "\nIngrese a que potencia desea elevar la matriz: ";
	std::cin >> potencia;
	while (potencia > 1) {
		matriz1 = matriz1 * matriz;
		potencia = potencia - 1;
	}
	std::cout << "\ntMatriz final: \n";
	std::cout << matriz1 << std::endl;
}

//SEGUNDO PUNTO
void realizarDemostracion() {
	matriz << 0, 1, 1,
		1, 0, 1,
		1, 1, 0;

	matriz1 << 2, 0, 0,
		0, 2, 0,
		0, 0, 2;

	std::cout << "\ntMatriz A: \n" << matriz << std::endl;
	std::cout << "\nDemostracion: \n" << (matriz * matriz) - matriz - matriz1 << std::endl;
}

//PRIMER PUNTO
void operacionesBasicas() {
	matriz << 2, 0, 1,
		3, 0, 0,
		5, 1, 1;
	matriz1 << 1, 0, 1,
		1, 2, 1,
		1, 1, 0;
	std::cout << "\n\nMATRIZ A: \n" << matriz << std::endl;
	std::cout << "\n\nMATRIZ B: \n" << matriz1 << std::endl;
	std::cout << "\n\nOperaciones: " << std::endl;
	std::cout << "\n\nA + B: \n" << matriz + matriz1 << std::endl;
	std::cout << "\n\nA - B: \n" << matriz - matriz1 << std::endl;
	std::cout << "\n\nA * B: \n" << matriz * matriz1 << std::endl;
	std::cout << "\n\nB * A: \n" << matriz1 * matriz << std::endl;
	std::cout << "\n\nA transpuesta: \n" << matriz.transpose() << std::endl;
}

//MENU DEL SOFTWARE
void menu() {
	int men;
	std::cout << "\n\n\t\t\t\t\t\t\tMENU " << std::endl;
	std::cout << "\n\t\t\t\t\t1. Operaciones basicas con matrices " << std::endl;
	std::cout << "\t\t\t\t\t2. Realiza la siguiente demostracion " << std::endl;
	std::cout << "\t\t\t\t\t3. n-esima potencia de la matriz  " << std::endl;
	std::cout << "\t\t\t\t\t4. Matiz inversa  " << std::endl;
	std::cout << "\t\t\t\t\t5. Sistema de ecuaciones con matrices " << std::endl;
	std::cout << "\t\t\t\t\t6. Analisis de problemas usando matrices  " << std::endl;
	std::cout << "\t\t\t\t\t7. Rango de una matriz  " << std::endl;
	std::cout << "\t\t\t\t\t8. Ecuaciones de una incognita en matrices  " << std::endl;
	std::cout << "\t\t\t\t\t9. De un sistema de ecuaciones a una matriz " << std::endl;
	std::cout << "\t\t\t\t\t0. SALIR " << std::endl;

	std::cout << "\n\t\t\t\t\tIngrese una menu: ";
	std::cin >> men;
	std::cout << "\n\n";

	//SWITCH PARA ESCOGER EL EJERCICIO QUE SE QUIERA REVISAR
	switch (men) {

	case 1:
		//PRIMER EJERCICIO
		operacionesBasicas();
		system("pause>0");
		system("cls");
	break;

	case 2:
		//SEGUNDO EJERCICIO
		realizarDemostracion();
		system("pause>0");
		system("cls");
	break;

	case 3:
		//TERCERO EJERCICIO
		nEsima();
		system("pause>0");
		system("cls");
	break;

	case 4:
		//CUARTO EJERCICIO
		matrizInv();
		system("pause>0");
		system("cls");
		break;

	case 5:
		//QUINTO EJERCICIO
		sistemaEcuaciones();
		system("pause>0");
		system("cls");
	break;

	case 6:
		//SEXTO EJERCICIO
		analisisProblemas();
		system("pause>0");
		system("cls");
	break;

	case 7:
		//SEPTIMO EJERCICIO
		rangoMatriz();
		system("pause>0");
		system("cls");
	break;

	case 8:
		//OCTAVO EJERCICIO
		ecuacionIncognita();
		system("pause>0");
		system("cls");
	break;

	case 9:
		//NOVENO EJERCICIO
		sistemaEcuacion();
		system("pause>0");
		system("cls");
		break;

	case 0:
		//OPCION SALIR DEL SOFTWARE
		std::cout << "Salida exitosa!!" << std::endl;
		system("pause>0");
		exit(0);

	default:
		//OPCION INVALIDA
		std::cout << "SELECCIONO UNA OPCION INVALIDA, INTENTELO DE NUEVO" << std::endl;
		system("pause>0");
		system("cls");
	}

	//Recursividad menu
	menu();
}

//FUNCION PRINCIPAL DEL SOFTWARE
int main() {
	std::cout << "\n\n\n\n\n\n\n\n\n\t\t\t\tBIENVENIDO AL PROGRAMA DE EJERCICIOS OPERACIONES CON MATRICES\n\n\t\t\t\t\t\t\t\t\tBy: Bryan Hernandez y Daniel Olarte " << std::endl;
	system("pause>0");
	system("cls");
	menu();
	
}
