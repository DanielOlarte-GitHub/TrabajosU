/*
	Arquitectura de Computadores
	Daniel Alejandro Olarte Avila
	Bryan Ferney Hernandez 
	23/08/21
*/

#include <iostream>
#include <conio.h>
#include <stdlib.h> //New y Delete

using namespace std;

void llenarArreglo();
void mostrarValores();

int tamArreglo, *arr;

int main(){
	llenarArreglo();
	mostrarValores();
	
	delete[] arr; // Despues del new, se pone el delete para liberear la memoria ocupada por el arr en bytes reservado anteriormente
	
}

void llenarArreglo(){
	cout<<"\t\tDigite que tama�o quiere que tenga el arreglo: ";
	cin>>tamArreglo;
	cout<<"\n\n"<<endl;
	
	arr = new int[tamArreglo]; // Primero se reserva el numero de bytes que se solicito en las anteriores lineas de codigo
	
	for(int i=0; i<tamArreglo; i++){
		cout<<"\t\tIngrese un valor al arreglo: ";
		cin>>arr[i];
		cout<<"\n"<<endl;
	}
}


void mostrarValores(){
	cout<<"\n\t\tLOS VALORES SON:\n\n"<<endl;
	for(int i =0; i<tamArreglo; i++){
		cout<<"\t\t\t"<<arr[i]<<endl;
	}
}
