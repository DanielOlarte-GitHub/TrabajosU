#include <iostream>
using namespace std;

int main(){
	
	string usuarioUsu, contrasenaUsu;
	string usuario = "Daniel";
	string contrasena = "123";
	bool bandera=true;
	
	cout<<"\n\n\t\tBIENVENIDO AL EJERCICIO DE USUARIO Y CONTRASE�A"<<endl;
	system("pause");
	system("cls");
	
	while(bandera){
		cout<<"\n\n\t\tDigite el usuario\n\t\t";
		cin>>usuarioUsu;
	
		cout<<"\t\tDigite la contrase�a\n\t\t";
		cin>>contrasenaUsu;
	
		if(usuarioUsu==usuario && contrasenaUsu == contrasena){
			cout<<"\t\tFelicidades a entrado"<<endl;
			bandera = false;
		}else{
			cout<<"\t\tIntentelo de nuevo"<<endl;
			
		}
	}
	
	cout<<"\n\n\t\t\tGRACIAS POR USAR EL PROGRAMA"<<endl;
	system("pause>0");
	
}
