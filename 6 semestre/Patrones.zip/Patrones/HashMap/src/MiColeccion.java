
import java.util.HashMap;
import java.util.Iterator;

/*
Juan Carlos Castro
 */
public class MiColeccion {

    private HashMap<String, Estudiante> coleccionEstudiante;

    public MiColeccion() {
        coleccionEstudiante = new HashMap<String, Estudiante>();
    }

    public void anexarRegistro(String codigo, Estudiante unEstudiante) {
        coleccionEstudiante.put(codigo, unEstudiante);
    }

    public void mostrarColeccion() {
        System.out.println("Mostrar la colección");
        System.out.println(coleccionEstudiante);
    }

    public void borrarRegistro(String codigo) {
        coleccionEstudiante.remove(codigo);
    }

    public void actualizarRegistro(String codigo, Estudiante unEstudiante) {
        coleccionEstudiante.put(codigo, unEstudiante);
    }

    public void imprimirColeccion() {
        System.out.println("Visualizar la Coleccion");
        System.out.println(coleccionEstudiante.entrySet());
    }

    public void imprimircoleccionEstudiante() {
        System.out.println("Imprimir cllaes y el valor");
        System.out.println(coleccionEstudiante.keySet());
        System.out.println(coleccionEstudiante.values());

    }

    public void imprimircoleccionEstudiante2() {
        System.out.println("Iterador...");
        Iterator<String> it = coleccionEstudiante.keySet().iterator();
        while (it.hasNext()) {
            String clave = it.next();
            if (coleccionEstudiante.get(clave).getApellido() == "Camargo") {
                System.out.println(clave + " - " + coleccionEstudiante.get(clave));
                
                System.out.println("este es el estudiante:\t" + coleccionEstudiante.get(clave));
                System.out.println("\nEl apellido es: " + coleccionEstudiante.get(clave).getApellido() + "\n");
            }
        }
    }

}
