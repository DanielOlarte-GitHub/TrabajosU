/*
Juan Castro
 */
public class TestMiColeccion {
    private MiColeccion mc;
    
    public TestMiColeccion(){
        this.mc = new MiColeccion();
    }
    
    public void procesarDatos(){
        System.out.println("Mi Coleccion Maps");
        
        //Insertar al final de la lista
        mc.anexarRegistro("120",new Estudiante("Bryan", "Carrillo"));
        mc.anexarRegistro("121",new Estudiante("Ruben", "Camargo"));
        mc.anexarRegistro("122",new Estudiante("Martha", "Rios"));
        mc.anexarRegistro("123", new Estudiante("Juan", "Hilarion"));
        mc.anexarRegistro("124", new Estudiante("Oscar", "Perez"));
        mc.anexarRegistro("125", new Estudiante("Sergio", "Delgado"));
        mc.anexarRegistro("126", new Estudiante("Julieth","Hernandez"));
        
        //imprimir coleccion
        mc.mostrarColeccion();
        
        //borrar un elemento
        mc.borrarRegistro("122");
        
       //imprimir coleccion
       mc.imprimircoleccionEstudiante();
       
       //actualizar o sobreescribir datos de la coleccion
       mc.actualizarRegistro("123", new Estudiante("Luis Alfredo", "Navas Reyes"));
       mc.imprimirColeccion();
        System.out.println("\nsegunda manera\n");
       mc.imprimircoleccionEstudiante2();
       
    }
    
    public static void main(String[] args) {
        TestMiColeccion tm = new TestMiColeccion();
        tm.procesarDatos();
    }
}
