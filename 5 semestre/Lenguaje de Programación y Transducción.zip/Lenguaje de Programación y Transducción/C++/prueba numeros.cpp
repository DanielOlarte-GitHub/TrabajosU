#include <iostream>
using namespace std;
int i;

int main(){
	
	for(i = 1; i<=20; i++){
		cout<<i<<endl;
	}
	
}
