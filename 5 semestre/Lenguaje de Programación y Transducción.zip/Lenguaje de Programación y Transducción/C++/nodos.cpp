#include <iostream>
using namespace std;

struct	NodoA{
	int dato;
	NodoA *der;
	NodoA *izq;
};

NodoA *crearNodos(int dato){
	NodoA *nnodo = new NodoA();
	nnodo->dato = dato;
	nnodo->der = NULL;
	nnodo->izq = NULL;
	return nnodo;	
}

NodoA *arbol = NULL;

int i, op, dato, contador=0, prom, suma=0;
bool seguir = true;



//Se recorre el arbol de forma PostOrden
void recorridoPostOrden(NodoA  *arbol){
	
	if(arbol==NULL)
	{
		return;
	}else{
		recorridoPostOrden(arbol->izq);
		recorridoPostOrden(arbol->der);
		cout<<arbol->dato<<"\t";
	}
} 


//Muestra el arbol recorrido InOrden
void recorridoInOrden(NodoA *arbol){
	if(arbol==NULL)
  {
      return;	
  }
  else
  {
      recorridoInOrden(arbol->izq);
      cout<<arbol->dato<<"\t";
      recorridoInOrden(arbol->der);
      
  }
}


//Muestra cual es el nivel del arbol
int nivel(NodoA *arbol){
	int a, b;
	if(arbol == NULL){
		return 0;
	}else{
		a = nivel(arbol->izq);
		b = nivel(arbol->der);
	}
	
	if(a>b){
		return a+1;
	}else{
		return b+1;
	}
	
}


//Muesta si el arbol es perfecto o no
void perfecto(NodoA *arbol){
	int izq,der;
	if(arbol==NULL)
	{
		return ;
    } else
    {
    	nivel(arbol->izq);
		nivel(arbol->der);
		if(nivel(arbol->izq)==nivel(arbol->der)){
			cout<<" Arbol es Perfecto "<<endl;
		}else{
			cout<<" Arbol no es Perfecto "<<endl;
		}
	}
} 


//Muestra cual es el peso del arbol
void peso(int cont){
	cout<<"\nEl peso del arbol es: "<<cont<<endl;
}


//Se saca el promedio de todos los valores del arbol
void promedio(int cont, int suma){
	prom = suma/cont;
	cout<<endl;
	cout<<"El promedio es: " << prom <<endl<<endl;
}


//Se muestra el arbol en forma horizontal
void mostrar(NodoA *arbol, int cont)
{
	if(arbol==NULL){
		
		return;
	}else{
		mostrar(arbol->der, cont+1);
		for(int i=0; i<cont; i++){
			cout<<"\t";
		}
		cout<<arbol->dato<<endl;
		mostrar(arbol->izq, cont+1);
	}
}


//Se inserta un nodo al arbol
void insertar(NodoA *&arbol, int dato){
	if (arbol==NULL){
		NodoA *nnodo = crearNodos(dato);
		arbol = nnodo;
		
	}else{
		
		int d1 = arbol->dato ;
		if(dato<d1){
		
			insertar(arbol->izq,dato);
		}else{
		
			insertar(arbol->der,dato);
		}
		
	}
	
}

//Recorre el arreglo creado en PreOrden
void recorridoPreOrden(NodoA *arbol){
	if(arbol== NULL){
		return;
			
	}else{
		cout<<arbol->dato<<"\t";
		
	}
	
	recorridoPreOrden(arbol->izq);
	recorridoPreOrden(arbol->der);
	
}


//Menu con cada funcion
void menu(){
	
	do{
		system("cls");
		cout<<"Ingresar valores a un arbol\n"<<endl;
		cout<<"1) Ingresar la nota del estudiante"<<endl;
		cout<<"2) Mostrar"<<endl;
		cout<<"3) Saber el Promedio del arbol"<<endl;
		cout<<"4) Saber el peso del arbol"<<endl;
		cout<<"5) Saber el nivel del arbol"<<endl;
		cout<<"6) Saber si es binario o no el arbol"<<endl;
		cout<<"7) Recorrido en PreOrden"<<endl;
		cout<<"8) Recorrido en PostOrden"<<endl;
		cout<<"9) Recorrido en InOrden"<<endl;
		cout<<"10) Salir"<<endl;
		cout<<"Ingrese la opcion"<<endl;
		cin>>op;
		switch(op){
			case 1:
				system("cls");
				cout<<"Ingrese el elemento"<<endl;
				cin>>dato;
				insertar(arbol, dato);
				suma += dato;
				contador ++;
				cout<<endl;
			break;
			
			case 2:
				system("cls");
				mostrar(arbol, contador);
				system("pause");
			break;
			
			case 3:
				system("cls");
				promedio(contador, suma);
				system("pause");
			break;
			
			case 4:
				system("cls");
				peso(contador);
				system("pause");
			break;
			
			case 5:
				system("cls");
				cout<<"El nivel del arbol es: "<<nivel(arbol)<<endl;
				system("pause");
			break;
			
			case 6:
				system("cls");
				perfecto(arbol);
				system("pause");
			break;
			
			case 7:
				system("cls");
				recorridoPreOrden(arbol);
				cout<<endl;
				system("pause");
			break;	
			
			case 8:
				system("cls");
				recorridoPostOrden(arbol);
				cout<<endl;
				system("pause");
			break;	
			
			case 9:
				system("cls");
				recorridoInOrden(arbol);
				cout<<endl;
				system("pause");
			break;	
				
			case 10:
				cout<<"GRACIAS POR USAR EL PROGRAMA"<<endl;
				seguir=false;
			break;
			
			default:
				cout<<"Digito un dato invalido"<<endl;
			break;	
		}
		
	}while(seguir==true);
}

//Metodo principal
int main(){
	menu();
}
