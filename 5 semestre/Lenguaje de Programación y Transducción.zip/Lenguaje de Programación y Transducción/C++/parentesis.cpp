#include <iostream>
#include <string.h>
#include <stack>
using namespace std;

char secuencia[40];

void mostrar(){
	for(int i= 0; i<strlen(secuencia); i++){
		cout<<secuencia[i]<<" ";
	}
}

void comprobar(){
	int contador=0;
	bool bandera = true;
	for(int i=0; i<strlen(secuencia);i++){
		if(secuencia[i]=='('){
			contador++;
		}else if(secuencia[i]==')'){
			contador--;
		}
		if(contador<0){
			bandera=false;
			break;
		
		}	
	}
	
	if(contador==0){
		cout<<"FELICIDADES SU SECUENCIA ES CORRECTA"<<endl;
	}else{
		cout<<"SU SECUENCIA NO FUE CORRECTA"<<endl;
	}
}


void agregar(){
	
	cout<<"Dijite su secuencia de parentesis"<<endl;
//	cin>>secuencia;
//	gets(secuencia);
cin.ignore();
cin.getline(secuencia,40,'\n');
}


void menu(){
	system("pause");
	system("cls");
	cout<<"\n\n\t\t\t\t\t\t\tMenu:\n\n\t\t\t\t\t1) Hacer mi secuencia de parentesis\n\t\t\t\t\t2) Comprobarlo\n\t\t\t\t\t3) Mostrar mi secuencia\n\t\t\t\t\t0) Salir del programa\n"<<endl;
	int men;
	cin>>men;
	switch(men){
		case 1:
			agregar();
		break;
		
		case 2:
			comprobar();
		break;
		
		case 3:
			mostrar();
		break;
		
		case 0:
			cout<<"\n\n\t\t\t\t\tGRACIAS POR USAR EL PROGRAMA\n\n"<<endl;
			exit(0);
		break;
		
		default:
			cout<<"Dijito una opcion incorrecta, intentelo de nuevo\n"<<endl;
		break;	
	}
	menu();
}

int main(){
	cout<<"\n\n\t\t\t\tBIENVENIDO AL CODIGO DE COMPROBACION DE PARENTESIS\n\t\t\t\t\t\tby:Daniel Olarte\n\n"<<endl;
	menu();
}
