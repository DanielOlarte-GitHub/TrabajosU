#include <iostream>
using namespace std;

int a[10]={10,4,6,2,7,1,5,9,8,3};
int *p_a;

int main(){
	p_a = a;
	
	//Imprimiendo Arreglo Normal
	cout<<'ARREGLO ANTES DE LOS CAMBIOS\n'<<endl;
	for(int i =0; i<10;i++){
		cout<<*p_a++<<endl;
	}
	
	
	///Cambiando los datos a traves del puntero
	for(int j=0; j<10;j++){
	
		*p_a--=j;
	}
	
	//Imprimiendo Arreglo con los cambios 
	cout<<"\nARREGLO DESPUES DE LOS CAMBIOS\n"<<endl;
	for(int k =0; k<10;k++){
		cout<<*p_a++<<endl;
	}
}
