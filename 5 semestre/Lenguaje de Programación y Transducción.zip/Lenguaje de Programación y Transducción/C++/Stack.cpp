#include <iostream>
#include <stack>

using namespace std;

stack <int> pila1;
stack <int> pila2;
int main(){
	pila1.push(1);
	pila1.push(2);
	pila1.push(3);
	pila1.push(4);
	pila1.push(5);
	
	cout<<"El tama�o de la pila es: "<<pila1.size()<<endl;
	cout<<"Estado de la pila <0> hay datos <1> no hay datos: "<<pila1.empty()<<endl;
	cout<<"La cima de la pila es: "<<pila1.top()<<endl;
	pila1.pop();
	cout<<"La cima de la pila es: "<<pila1.top()<<endl;
	pila1.pop();
	pila1.pop();
	pila1.pop();
	pila1.pop();
	if(pila1.size()>=1){
		cout<<"top pila 1 :"<<pila1.top()<<endl;
		pila1.pop();
	}else{
		cout<<"Pila sin elementos"<<endl;
	}
		
	
	
	
	
}
