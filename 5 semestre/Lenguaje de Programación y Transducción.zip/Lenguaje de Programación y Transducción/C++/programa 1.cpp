//Librerias
#include <iostream>
using namespace std;
//Definir Variables
int a,b,c;

int main(){
	cout<<"Ingrese primer valor" <<endl;	
	cin>>a;
	cout<<"Ingrese segundo valor" <<endl;	
	cin>>b;
	c=a+b;
	cout<<"El resultado de la suma de los numeros ingresados es: "<<c<<endl;

}
