#include <iostream>
#include <string.h>

using namespace std;

//Se crea las dos cadenas de caracteres, una para antes del igual y otra pal despues a   =   b+2/e
char antesI[20]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
char despuesI[20]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

//Metodo para mostrar lo que digito el usuario
void mostrar(){
	cout<<"\n\n\t\t\t\t\t       MOSTRAR:\n\n\t\t\t\t\t";
	for(int i= 0; i<strlen(antesI); i++){
		cout<<antesI[i];
	}
	
	cout<<" = ";
	
	for(int i= 0; i<strlen(despuesI); i++){
		cout<<despuesI[i];
	}
	
	cout<<endl;
}

//metodo para comprobar si esta bien o mal escrito
void comprobar(){
	bool bandera = true, banderaa=false;
	for(int i=0; i<strlen(antesI);i++){
		if(antesI[i]=='+' || antesI[i]=='-' || antesI[i]=='*' || antesI[i]=='/' || antesI[i]=='=' || antesI[0]=='0' || antesI[0]=='1' || antesI[0]=='2' || antesI[0]=='3' || antesI[0]=='4' || antesI[0]=='5' || antesI[0]=='6' || antesI[0]=='7' || antesI[0]=='8' || antesI[0]=='9' || antesI[i]==',' || antesI[i]=='.'   ){
			bandera = false;
			break;
		}

	}
	
	for(int i=0; strlen(antesI); i++){
		if(antesI[i]==0){
			banderaa=false;
		}else{
			banderaa=true;
			break;
		}
	}
	
	
	bool bandera2 = true, banderaa2=false;
	for(int i=0; i<strlen(despuesI);i++){
		if(despuesI[i]=='=' || despuesI[i]==',' || despuesI[i]=='.' || despuesI[i]=='#' || despuesI[i]=='?' || despuesI[i]=='�' ){
			bandera2 = false;
			break;
		}
	}
	
	for(int i=0; i<strlen(despuesI);i++){
		if(despuesI[i]==0){
			banderaa2=false;
		}else{
			banderaa2=true;
			break;
		}
	}
	
	
	if(bandera==true && bandera2 == true && banderaa==true && banderaa2==true){
		cout<<"\n\n\t\t\t\t\tFELICIDADES SU LINEA DE CODIGO ES CORRECTA"<<endl;
	}else{
		cout<<"\n\n\t\t\t\t\tSU LINEA DE CODIGO NO FUE CORRECTA"<<endl;
	}
}

//Metodo para escribir la linea de codigo a=a+b+2
void escribir(){
	cout<<"\n\n\t\t\t\t\t             ESCRIBIR: \n"<<endl;
	cout<<"\t\t\t\t\tEscriba lo que quiere poner antes del =\n\t\t\t\t\t";
	cin.ignore();
	cin.getline(antesI,20,'\n');
	cout<<"\n\t\t\t\t\tEscriba lo que quiere poner despues del =\n\t\t\t\t\t";
	cin.ignore();
	cin.getline(despuesI,20,'\n');
}

//Metodo para el menu de la funcion
void menu(){
	cout<<"\n\n\t\t\t\t\t------------------------------------------"<<endl;
	cout<<"\t\t\t\t\t|               MENU (a=2+1)             |"<<endl;
	cout<<"\t\t\t\t\t|                                        |"<<endl;
	cout<<"\t\t\t\t\t| Escoja una de las siguientes opciones: |"<<endl;
	cout<<"\t\t\t\t\t|   1) Escribir lo que desea             |"<<endl;
	cout<<"\t\t\t\t\t|   2) Comprobar                         |"<<endl;
	cout<<"\t\t\t\t\t|   3) Mostrarlo                         |"<<endl;
	cout<<"\t\t\t\t\t|   4) Salir                             |"<<endl;
	cout<<"\t\t\t\t\t|                                        |"<<endl;
	cout<<"\t\t\t\t\t------------------------------------------"<<endl;
	int men;
	cin>>men;
	switch(men){
		case 1:
			system("cls");
			escribir();
			system("pause");
			system("cls");
		break;
		
		case 2:
			system("cls");			
			comprobar();
			system("pause");
			system("cls");
		break;
		
		case 3:
			system("cls");
			mostrar();
			system("pause");
			system("cls");
		break;
		
		case 0:
			cout<<"\n\n\t\t\t\t\t GRACIAS POR USAR EL PROGRAMA"<<endl;
			exit(0);
		break;
		
		default:
			cout<<"\n\n\t\t\t\t\tDIGITO ALGUNA OPCION INVALIDA INTENTE DE NUEVO"<<endl;
			system("pause");
			system("cls");
		break;	
	}
	menu();
}

//Metodo Principal
int main(){
	cout<<"\n\n\t\t\t\t\t-----------------------------------"<<endl;
	cout<<"\t\t\t\t\t|      BIENVENIDO AL PROGRAMA     |"<<endl;
	cout<<"\t\t\t\t\t|        By: Daniel Olarte        |"<<endl;
	cout<<"\t\t\t\t\t-----------------------------------"<<endl;
	system("pause");
	system("cls");
	menu();
}
