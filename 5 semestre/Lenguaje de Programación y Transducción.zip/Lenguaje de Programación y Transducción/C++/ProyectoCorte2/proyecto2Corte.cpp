#include <iostream>
#include <fstream>
#include <sstream> //CONVERTIR ENTERO A STRING
#include <cstdlib> //CONVERTIR STRING A ENTERO


using namespace std;
void menu();
ifstream leerCodigo;
ofstream escribirCodigo;
char caracter;
string cadena, convertir;
int cont=0;
int identificadores[8] = {100, 200, 300, 400, 500, 600, 700, 800};
string matrizEjercicio[300][2];
/*
					 Caracter(0)						Identificador(1)	
						
	1				     &                                    300          
	
	2					 p									  503
	
	3					int									  125
	
	...

*/

//COVERTIR UN ENTERO A UN STRING
string convertirIntaStr(int num){
	stringstream x;
	x<< num;
	return x.str();
}



/*
		MOSTRANDO INFORMACION AL USUARIO
*/

//MUESTRA TODAS LAS VARIABLES  PARA INFORMAR AL USUARIO
void verVariabl(){
	cout<<"\n\n\t\t\t\t\tTIPOS DE VARIABLES / IDENTIFICADORES\n"<<endl;
	cout<<"\t\t\t\t\t1.    ->    a"<<endl;
	cout<<"\t\t\t\t\t2.    ->    Variable"<<endl;
	cout<<"\t\t\t\t\t3.    ->    ejemplo2"<<endl;
	cout<<"\t\t\t\t\t4.    ->    var_iable"<<endl<<endl;
	cout<<"\t\t\t\t\t5.    ->    menu"<<endl<<endl;
}

//MUESTRA TODAS LAS PALABRAS RESERVADAS PARA INFORMAR AL USUARIO
void verPalabReserv(){
	
	cout<<"\n\n\t\t\t\t\tPALABRAS RESERVADAS\n"<<endl;
	cout<<"\t\t\t\t\t1.    ->    int"<<endl;
	cout<<"\t\t\t\t\t2.    ->    string"<<endl;
	cout<<"\t\t\t\t\t3.    ->    float"<<endl;
	cout<<"\t\t\t\t\t4.    ->    double"<<endl;
	cout<<"\t\t\t\t\t5.    ->    bool"<<endl;
	cout<<"\t\t\t\t\t6.    ->    true"<<endl;
	cout<<"\t\t\t\t\t7.    ->    false"<<endl;
	cout<<"\t\t\t\t\t8.    ->    break"<<endl;
	cout<<"\t\t\t\t\t9.    ->    case"<<endl;
	cout<<"\t\t\t\t\t10.   ->    char"<<endl;
	cout<<"\t\t\t\t\t11.   ->    cin"<<endl;
	cout<<"\t\t\t\t\t12.   ->    class"<<endl;
	cout<<"\t\t\t\t\t13.   ->    const"<<endl;
	cout<<"\t\t\t\t\t14.   ->    continue"<<endl;
	cout<<"\t\t\t\t\t15.   ->    cout"<<endl;
	cout<<"\t\t\t\t\t16.   ->    default"<<endl;
	cout<<"\t\t\t\t\t17.   ->    do"<<endl;
	cout<<"\t\t\t\t\t18.   ->    else"<<endl;
	cout<<"\t\t\t\t\t19.   ->    for"<<endl;
	cout<<"\t\t\t\t\t20.   ->    fstream"<<endl;
	cout<<"\t\t\t\t\t21.   ->    if"<<endl;
	cout<<"\t\t\t\t\t22.   ->    include"<<endl;
	cout<<"\t\t\t\t\t23.   ->    iostream"<<endl;
	cout<<"\t\t\t\t\t24.   ->    long"<<endl;
	cout<<"\t\t\t\t\t25.   ->    namespace"<<endl;
	cout<<"\t\t\t\t\t26.   ->    return"<<endl;
	cout<<"\t\t\t\t\t27.   ->    short"<<endl;
	cout<<"\t\t\t\t\t28.   ->    sizeof"<<endl;
	cout<<"\t\t\t\t\t29.   ->    static"<<endl;
	cout<<"\t\t\t\t\t30.   ->    struct"<<endl;
	cout<<"\t\t\t\t\t31.   ->    switch"<<endl;
	cout<<"\t\t\t\t\t32.   ->    using"<<endl;
	cout<<"\t\t\t\t\t33.   ->    void"<<endl;
	cout<<"\t\t\t\t\t34.   ->    while"<<endl;
	cout<<"\t\t\t\t\t35.   ->    endl"<<endl;
	cout<<"\t\t\t\t\t36.   ->    main"<<endl;
	cout<<"\t\t\t\t\t37.   ->    system"<<endl;
	cout<<"\t\t\t\t\t38.   ->    cls"<<endl;
	cout<<"\t\t\t\t\t35.   ->    pause"<<endl;
}

//MUESTRA LOS VALORES NUMERICOS PARA INFORMAR AL USUARIO
void verConst(){
	cout<<"\n\n\t\t\t\t\tCONSTANTES/VALORES NUMERICOS\n"<<endl;
	cout<<"\t\t\t\t\t1.    ->    0"<<endl;
	cout<<"\t\t\t\t\t2.    ->    1"<<endl;
	cout<<"\t\t\t\t\t3.    ->    2"<<endl;
	cout<<"\t\t\t\t\t4.    ->    3"<<endl;
	cout<<"\t\t\t\t\t5.    ->    4"<<endl;
	cout<<"\t\t\t\t\t6.    ->    5"<<endl;
	cout<<"\t\t\t\t\t7.    ->    6"<<endl;
	cout<<"\t\t\t\t\t8.    ->    7"<<endl;
	cout<<"\t\t\t\t\t9.    ->    8"<<endl;
	cout<<"\t\t\t\t\t10.    ->   9"<<endl;
}

//MUESTRE LOS SIMBOLOS ESPECIALES PARA INFORMAR AL USUARIO
void verSimbEsp(){
	cout<<"\n\n\t\t\t\t\tSIMBOLOS ESPECIALES\n"<<endl;
	cout<<"\t\t\t\t\t1.    ->    &"<<endl;
	cout<<"\t\t\t\t\t2.    ->    |"<<endl;
	cout<<"\t\t\t\t\t3.    ->    &&"<<endl;
	cout<<"\t\t\t\t\t4.    ->    ||"<<endl;
	cout<<"\t\t\t\t\t5.    ->    #"<<endl;
	cout<<"\t\t\t\t\t5.    ->    '\'"<<endl;
}

//MUESTRA LOS OPERADORES MATEMATICOS PARA INFORMAR AL USUARIO
void verOperMat(){
	cout<<"\n\n\t\t\t\t\tOPERADORES MATEMATICOS\n"<<endl;
	cout<<"\t\t\t\t\t1.    ->    +"<<endl;
	cout<<"\t\t\t\t\t2.    ->    -"<<endl;
	cout<<"\t\t\t\t\t3.    ->    *"<<endl;
	cout<<"\t\t\t\t\t4.    ->    /"<<endl;
	cout<<"\t\t\t\t\t5.    ->    %"<<endl;
}

//MUESTRA LOS SIGNOS DE PUNTUACION PARA INFORMAR AL USUARIO
void verSigPunt(){
	cout<<"\n\n\t\t\t\t\tSIGNOS DE PUNTUACION\n"<<endl;
	cout<<"\t\t\t\t\t1.    ->    ("<<endl;
	cout<<"\t\t\t\t\t2.    ->    )"<<endl;
	cout<<"\t\t\t\t\t3.    ->    ."<<endl;
	cout<<"\t\t\t\t\t4.    ->    ,"<<endl;
	cout<<"\t\t\t\t\t5.    ->    ;"<<endl;
	cout<<"\t\t\t\t\t6.    ->    \""<<endl;
	cout<<"\t\t\t\t\t7.    ->    \'"<<endl;
	cout<<"\t\t\t\t\t8.    ->    {"<<endl;
	cout<<"\t\t\t\t\t9.    ->    }"<<endl;
	cout<<"\t\t\t\t\t10.   ->    ["<<endl;
	cout<<"\t\t\t\t\t11.   ->    ]"<<endl;
}

//MUESTRA LOS OPERADORES RELACIONALES PARA INFORMAR AL USUARIO
void verOperRel(){
	cout<<"\n\n\t\t\t\t\tOPERADORES RELACIONALES\n"<<endl;
	cout<<"\t\t\t\t\t1.    ->    =="<<endl;
	cout<<"\t\t\t\t\t2.    ->    <"<<endl;
	cout<<"\t\t\t\t\t3.    ->    >"<<endl;
	cout<<"\t\t\t\t\t4.    ->    !"<<endl;
	cout<<"\t\t\t\t\t5.    ->    <="<<endl;
	cout<<"\t\t\t\t\t6.    ->    >="<<endl;
	cout<<"\t\t\t\t\t7.    ->    !="<<endl;
}

//MUESTRA LOS OPERADORES DE ASIGNACION PARA INFORMAR AL USUARIO
void verOperAsig(){
	cout<<"\n\n\t\t\t\t\tOPERADORES DE ASIGNACION\n"<<endl;
	cout<<"\t\t\t\t\t1.    ->    ="<<endl;
}

//SEGUNDO MENU PARA INFORMAR AL USUARIO
void menuVerDatos(){
	int men;
	system("cls");
	cout<<"\n\n\t\t\t\t\t\tMENU VER DATOS ESPECIFICOS\n"<<endl;
	cout<<"\t\t\t\t\t1) Ver los Operadores de asignaci�n"<<endl;
	cout<<"\t\t\t\t\t2) Ver los Operadores relacionales"<<endl;
	cout<<"\t\t\t\t\t3) Ver los Signos de puntuacion"<<endl;
	cout<<"\t\t\t\t\t4) Ver los Operadores Matematicos"<<endl;
	cout<<"\t\t\t\t\t5) Ver los Simbolos Especiales"<<endl;
	cout<<"\t\t\t\t\t6) Ver las Constantes"<<endl;
	cout<<"\t\t\t\t\t7) Ver las Palabras reservadas"<<endl;
	cout<<"\t\t\t\t\t8) Ver los Tipos de Variables"<<endl;
	cout<<"\t\t\t\t\t0) Salir al menu principal\n\n\t\t\t\t\tSu Opcion: ";
	cin>>men;
	
	switch(men){
		case 1:
			system("cls");
			verOperAsig();
			system("pause");
		break;
		
		case 2:
			system("cls");
			verOperRel();
			system("pause");
		break;
		
		case 3:
			system("cls");
			verSigPunt();
			system("pause");
		break;

		case 4:
			system("cls");
			verOperMat();
			system("pause");
		break;
		
		case 5:
			system("cls");
			verSimbEsp();
			system("pause");
		break;
		
		case 6:
			system("cls");
			verConst();
			system("pause");
		break;
		
		case 7:
			system("cls");
			verPalabReserv();
			system("pause");
		break;
		
		case 8:
			system("cls");
			verVariabl();
			system("pause");
		break;		
		case 0:
			system("cls");
			menu();
		break;
		
		default:
			system("cls");
			system("pause");	
			cout<<"\n\n\t\t\t\t\tDIGITO UNA OPCION INVALIDA, INTENTE DE NUEVO"<<endl;
		break;
	}
	menuVerDatos();
		
}



/*
		COMPROBACIONES
*/

//COMPRUEBA SI LA PALABRA ES UNA PALABRA RESERVADA
bool comprobacionPalabrasReservadas(string palabra){
	bool flag = false;
	string arreglo[40]= {"int","string","float","double","bool","true","false","break","case","char","cin","class","const","continue","cout","default","do","else","for","fstream","if","include","iostream","long","namespace","return","short","sizeof","static","struct","switch","using","void","while", "endl", "main", "system", "cls", "pause", "std"};
	
	for(int i=0;i<40; i++){
		if(palabra == arreglo[i])
			return true;
	}
	return false;
}

//COMPRUEBA SI EL CARACTER ES UN VALOR NUMERICO 
bool comprobacionValoresNumericos (char caracter){
	bool flag=false;
	char arreglo[10] = {'0','1','2','3','4','5','6','7','8','9'};
	
	for(int i=0; i<10; i++){
		if(caracter == arreglo[i])
			return true;
	}
	return false;
}

//COMPRUEBA SI EL CARACTER ES UN SIMBOLO ESPECIAL
bool comprobacionSimbolosEspeciales(char caracter){
	bool flag = false;
	char arreglo[5] = {'&', '|','#'};
	
	for(int i=0; i<5; i++){
		if(caracter == arreglo[i])
			return true;
	}
		
	return false;
}

//COMPRUEBA SI EL CARACTER ES UN OPERADOR MATEMATICO
bool comprobacionOperadoresMatematicos(char caracter){
	bool flag = false;
	char arreglo[5] = {'+','-','*','/','%'};
	for(int i=0; i<5; i++){
		if(caracter == arreglo[i])
			return true;
	}
	return false;
}

//COMPRUEBA SI EL CARACTER ES UN SIGNO DE PUNTUACION
bool comprobacionSignosdePuntuacion(char caracter){
	bool flag = false;
	char arreglo[11] = {'(',')','.',',',';', '\"', '\'', '{', '}', '[', ']'};
	for (int i=0;i<11;i++){
		if(caracter == arreglo[i])
			return true;
	}
	return false;
}

//COMPRUEBA SI EL CARACTER ES UN SIGNO DE RELACION
bool comprobacionSignosRelacionales(char caracter){
	bool flag = false;
	char arreglo[3] = {'<', '>', '!'};
	for(int i=0; i<3; i++){
		if(caracter ==arreglo[i])
			return true;
	}
	return false;
}



//MUESTRA LAS CATEGORIAS PARA INFORMAR AL USUARIO
void verCategorias(){
	cout<<"\n\n\t\t\t\t\t\tCATEGORIAS DEL PATRON\n\n"<<endl;
	cout<<"\t\t\t\t\t    NOMBRE DE LA CATEGORIA          ID'S\n"<<endl; 
	cout<<"\t\t\t\t\t1) Operadores de asignacion  ->     100"<<endl;
	cout<<"\t\t\t\t\t2) Operadores Relacionales   ->     200"<<endl;
	cout<<"\t\t\t\t\t3) Signos de Puntuacion      ->     300"<<endl;
	cout<<"\t\t\t\t\t4) Operadores Matematicos    ->     400"<<endl;
	cout<<"\t\t\t\t\t5) Simbolos Especiales       ->     500"<<endl;
	cout<<"\t\t\t\t\t6) Constantes                ->     600"<<endl;
	cout<<"\t\t\t\t\t7) Palabras Reservadas       ->     700"<<endl;
	cout<<"\t\t\t\t\t8) Variables/Identificadores ->     800"<<endl;
}


//SE CREA UN TXT CON TODA LA INFORMACION Y SU RESPECTIVO RESUMEN
void resumen(){
	escribirCodigo<<"\n"<<"\t\t--------------------------------------------------------------------\n\n"<<endl;
	escribirCodigo<<"\n"<<"\t\t\tRESUMEN\n\n"<<endl;
	
	escribirCodigo<<"\n\n"<<"\t\t CATEGORIA \t\t\t\tCANTIDAD"<<endl;
	escribirCodigo<<"\n"<<"\t\t1) Operadores de asignacion\t\t    "<<(identificadores[0]-100)<<endl;
	escribirCodigo<<"\n\n"<<"\t\t CATEGORIA \t\t\t\tCANTIDAD"<<endl;
	escribirCodigo<<"\n"<<"\t\t2) Operadores Relacionales\t\t   "<<(identificadores[1]-200)<<endl;
	escribirCodigo<<"\n\n"<<"\t\t CATEGORIA \t\t\t\tCANTIDAD"<<endl;
	escribirCodigo<<"\n"<<"\t\t3) Signos de Puntuacion\t\t\t   "<<(identificadores[2]-300)<<endl;
	escribirCodigo<<"\n\n"<<"\t\t CATEGORIA \t\t\t\tCANTIDAD"<<endl;
	escribirCodigo<<"\n"<<"\t\t4) Operadores Matematicos\t\t    "<<(identificadores[3]-400)<<endl;
	escribirCodigo<<"\n\n"<<"\t\t CATEGORIA \t\t\t\tCANTIDAD"<<endl;
	escribirCodigo<<"\n"<<"\t\t5) Simbolos Especiales\t\t\t    "<<(identificadores[4]-500)<<endl;
	escribirCodigo<<"\n\n"<<"\t\t CATEGORIA \t\t\t\tCANTIDAD"<<endl;
	escribirCodigo<<"\n"<<"\t\t6) Constantes\t\t\t\t   "<<(identificadores[5]-600)<<endl;
	escribirCodigo<<"\n\n"<<"\t\t CATEGORIA \t\t\t\tCANTIDAD"<<endl;
	escribirCodigo<<"\n"<<"\t\t7) Palabras Reservadas\t\t\t    "<<(identificadores[6]-700)<<endl;
	escribirCodigo<<"\n\n"<<"\t\t CATEGORIA \t\t\t\tCANTIDAD"<<endl;
	escribirCodigo<<"\n"<<"\t\t8) Variables/Identificadores\t\t   "<<(identificadores[7]-800)<<endl;
	
	escribirCodigo.close();
}

//IMPRIME TODA LA INFORMACION
void imprimir(){
	escribirCodigo.open("Informacion.txt");
	cout<<"\n\n\t\t\t\t\tMOSTRANDO EL ARCHIVO "<<endl;
	cout<<"\n\n"<<endl;
	for(int i=0; i<cont; i++){
		cout<<"\t\t--------------------------------------------------------------------"<<endl;
		escribirCodigo<<"\n"<<"\t\t--------------------------------------------------------------------"<<endl;
		cout<<"\n\n\t\t\t\tCARACTER:\t\t"<<matrizEjercicio[i][0]<<endl;
		escribirCodigo<<"\n"<<"\n\n\t\t\t\tCARACTER:\t\t"<<matrizEjercicio[i][0]<<endl;
		cout<<"\n\t\t\t\tIDENTIFICADOR:\t\t"<<matrizEjercicio[i][1]<<endl;
		escribirCodigo<<"\n"<<"\n\t\t\t\tIDENTIFICADOR:\t\t"<<matrizEjercicio[i][1]<<endl;
	
		switch((atoi(matrizEjercicio[i][1].c_str())+2)/100){
			case 1:
				cout<<"\n\t\t\t\tCATEGORIA:\t\tOperadores de Asignacion"<<endl;
				escribirCodigo<<"\n"<<"\n\t\t\t\tCATEGORIA:\t\tOperadores de Asignacion"<<endl;
			break;
			
			case 2:
				cout<<"\n\t\t\t\tCATEGORIA:\t\tOperadores Relacionales"<<endl;
				escribirCodigo<<"\n"<<"\n\t\t\t\tCATEGORIA:\t\tOperadores Relacionales"<<endl;
			break;

			case 3:
				cout<<"\n\t\t\t\tCATEGORIA:\t\tSignos de Puntuacion"<<endl;
				escribirCodigo<<"\n"<<"\n\t\t\t\tCATEGORIA:\t\tSignos de Puntuacion"<<endl;
			break;
			
			case 4:
				cout<<"\n\t\t\t\tCATEGORIA:\t\tOperador Matematico"<<endl;
				escribirCodigo<<"\n"<<"\n\t\t\t\tCATEGORIA:\t\tOperador Matematico"<<endl;
			break;
			
			case 5:
				cout<<"\n\t\t\t\tCATEGORIA:\t\tSimbolos Especiales"<<endl;
				escribirCodigo<<"\n"<<"\n\t\t\t\tCATEGORIA:\t\tSimbolos Especiales"<<endl;
			break;
			
			case 6:
				cout<<"\n\t\t\t\tCATEGORIA:\t\tConstantes"<<endl;
				escribirCodigo<<"\n"<<"\n\t\t\t\tCATEGORIA:\t\tConstantes"<<endl;
			break;
			
			case 7:
				cout<<"\n\t\t\t\tCATEGORIA:\t\tPalabras Reservadas"<<endl;
				escribirCodigo<<"\n"<<"\n\t\t\t\tCATEGORIA:\t\tPalabras Reservadas"<<endl;
			break;
			
			case 8:
				cout<<"\n\t\t\t\tCATEGORIA:\t\tVariables/Identificadores"<<endl;
				escribirCodigo<<"\n"<<"\n\t\t\t\tCATEGORIA:\t\tVariables/Identificadores"<<endl;
			break;
		}
		cout<<endl;
	}
	
	resumen();
}


//SE LEE EL ARCHIVO 
void leerArchivo(){
	leerCodigo.open("ejemplomayo15Profe.txt");
	if(!leerCodigo.is_open()){
		cout<<"No se encontro el archivo\n"<<endl;
		exit(0);
	}
	
	while(!leerCodigo.eof()){
		caracter = leerCodigo.get();
		
		if(caracter ==  '='){
			char caracter2 = leerCodigo.get();
			if(caracter2 == '='){
				matrizEjercicio[cont][0] += "==";
				matrizEjercicio[cont][1] = convertirIntaStr(identificadores[1]);
				identificadores[1]++;
			}else{
				matrizEjercicio[cont][0] = '=';
				matrizEjercicio[cont][1] = convertirIntaStr(identificadores[0]);
				identificadores[0]++;
			}
			cont++;
		
		}else{
			if(comprobacionSignosRelacionales(caracter)){
				matrizEjercicio[cont][0] = caracter;
				matrizEjercicio[cont][1] = convertirIntaStr(identificadores[1]);
				identificadores[1]++;
				cont++;
			}else{
				if(comprobacionSignosdePuntuacion(caracter)){
					
					matrizEjercicio[cont][0] = caracter;
								
					matrizEjercicio[cont][1] = convertirIntaStr(identificadores[2]);
					identificadores[2]++;
					cont++;
				}else{
					if(comprobacionOperadoresMatematicos(caracter)){
						char caracter2 = leerCodigo.get();
						
						matrizEjercicio[cont][0] = caracter;
						matrizEjercicio[cont][1] = convertirIntaStr(identificadores[3]);
						identificadores[3]++;
						cont++;
						
					}else{
						if(comprobacionSimbolosEspeciales(caracter)){
							if (caracter == '&'){
								char caracter2 = leerCodigo.get();
								if(caracter2 == '&'){
									matrizEjercicio[cont][0] = "&&";
								}
								matrizEjercicio[cont][1] = convertirIntaStr(identificadores[4]);
								identificadores[4]++;
								
							}else if(caracter == '|'){
								char caracter2 = leerCodigo.get();
								if(caracter2 == '|'){
									matrizEjercicio[cont][0] = "||";
								}
								matrizEjercicio[cont][1] = convertirIntaStr(identificadores[4]);
								identificadores[4]++;
								
							}else{
								matrizEjercicio[cont][0] = caracter;
								matrizEjercicio[cont][1] = convertirIntaStr(identificadores[4]);
								identificadores[4]++;
							}
							cont++;
							
						}else{
							if(comprobacionValoresNumericos(caracter)){
								char caracter2 = leerCodigo.get();
								if(comprobacionValoresNumericos(caracter2)){
									matrizEjercicio[cont][0] += caracter;
									matrizEjercicio[cont][0] += caracter2;
									matrizEjercicio[cont][1] = convertirIntaStr(identificadores[5]);
									identificadores[5]++;
									cont++;
								}else{
									matrizEjercicio[cont][0] += caracter;
									matrizEjercicio[cont][0] += caracter2;
									matrizEjercicio[cont][1] = convertirIntaStr(identificadores[5]);
									identificadores[5]++;
									cont++;
								}
								
							}else{
								if(caracter == ' '|| caracter == '\n' ){
									if(comprobacionPalabrasReservadas(cadena)){
										matrizEjercicio[cont][0] = cadena;
										matrizEjercicio[cont][1] = convertirIntaStr(identificadores[6]);
										identificadores[6]++;
										cont++;
										
									}else{
										if(caracter != '\n'){
											matrizEjercicio[cont][0] = cadena;
											matrizEjercicio[cont][1] = convertirIntaStr(identificadores[7]);
											identificadores[7]++;
											cont++;
										}
										
									}
									cadena="";
									cont++;
									
								}else{
									cadena += caracter;
								}
							}
						}
					}
				}
			}
		}
	}	
	imprimir();
	leerCodigo.close();
}



//MENU PRINCIPAL
void menu(){
	int men;
	system("cls");
	cout<<"\n\n\t\t\t\t\t\t\tMENU\n"<<endl;
	cout<<"\t\t\t\t\t1) Ver las Categorias del Patron"<<endl;
	cout<<"\t\t\t\t\t2) Ver los datos en especifico"<<endl;
	cout<<"\t\t\t\t\t3) Empezar a leer el archivo.txt"<<endl;
	cout<<"\t\t\t\t\t0) Salir del programa"<<"\n\n\t\t\t\t\tSu Opcion: ";
	cin>>men;
	
	switch(men){
		case 1:
			system("cls");
			verCategorias();
			system("pause");
		break;
		
		case 2:
			system("cls");
			menuVerDatos();
			system("pause");
		break;
		
		case 3:
			system("cls");
			leerArchivo();
			system("pause");
		break;
				
		case 0:
			system("cls");
			cout<<"\n\n\t\t\t\t\tGRACIAS POR USAR EL PROGRAMA"<<endl;
			exit(0);
		break;
		
		default:
			system("cls");	
			cout<<"\n\n\t\t\t\t\tDIGITO UNA OPCION INVALIDA, INTENTE DE NUEVO"<<endl;
			system("pause");
		break;
	}
	menu();
		
}


//FUNCION PRINCIPAL
int main(){
	cout<<"\n\n\n\n\n\t\t\t\t\tBIENVENIDO AL PROGRAMA DE LEXEMA\n\t\t\t\t\t\tBy:Daniel Olarte\n\n\n\n\n"<<endl;
	system("pause");
	menu();
}

