#include <iostream>
using namespace std;

int a=14;
int *p_a;

int main(){
	p_a = &a;
	cout<<"Ingrese un numero entero "<<endl;
	cin>>*p_a;
	cout<<"Direccion a = "<<&a<<endl;
	cout<<"Direccion de p_a = "<<&p_a<<endl;
	
	cout<<"Contenido de a = "<<a<<endl;
	cout<<"Contenido de p_a = "<<p_a<<endl;
	cout<<"Contenido de p_a = "<<*p_a<<endl;
	
	*p_a=15;
	cout<<"Contenido de p_a = "<<*p_a<<endl;
	cout<<"Contenido de a = "<<a<<endl;
	
}
