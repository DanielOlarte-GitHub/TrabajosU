/*
	Conversor de temperatura by: Daniel Olarte
	
	Celsius---->Fahrenheit	( �C � 9/5) + 32 =  �F
	Fahrenheit---->Celsius	( �F - 32) � 5/9 =  �C
	Celsius---->Kelvin	�C + 273.15 =  K
	Kelvin---->Celsius	K - 273.15 =  �C
	Fahrenheit---->Kelvin	( �F - 32) � 5/9 + 273.15 =  K
	Kelvin---->Fahrenheit	( K - 273.15) � 9/5 + 32 =  �F

*/

#include <iostream>
using namespace std;

double c, f, k;
double *p_c,*p_f,*p_k; 

int main(){
	p_c = &c;
	p_f = &f;
	p_k = &k;
	
	cout<<"Ingrese el valor de grados Celsius "<<endl;
	cin>>*p_c;
	cout<<"en grados Fahrenheits son: "<<(*p_c* 9)/5+32<<endl;
	cout<<"en grados Kelvin son: "<<*p_c + 273.15<<endl;
	
	cout<<"Ingrese el valor de grados Fahrenheit "<<endl;
	cin>>*p_f;
	cout<<"en grados Celsius son: "<<(*p_f-32)*5/9<<endl;
	cout<<"en grados Kelvin son: "<<(*p_f-32)*5/9+273.15<<endl;
	
	cout<<"Ingrese el valor de grados Kelvin"<<endl;
	cin>>*p_k;
	cout<<"en grados Celsius son: "<<*p_k-273.15<<endl;
	cout<<"en grados Fahrenheit son: "<<(*p_k - 273.15)*9/5+32<<endl;
	
	
	
}

