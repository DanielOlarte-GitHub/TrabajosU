#include<iostream>
using namespace std;

void decimalB(){
	int binario[8];
	int decimal;
	cout<<" \t\t\t\t\tINGRESE EL VALOR DECIMAL "<<endl;
	cin>>decimal;
	//Operacion
	for(int i=0;i<8;i++){
		binario[i]=decimal%2;
		decimal /=2;
		
	}
	
	//Impresion
	cout<<" \t\t\t\t\tEL NUMERO BINARIO ES: "<<endl;
	for(int i=7;i>=0;i--){
	  cout<<binario[i];
	}
	cout<<endl;
}
 
 
 void binarioD(){
 	int binario,result,aux=0;
 	int valor[8];
 	cout<<"\t\t\t\t\tINGRESE EL VALOR BINARIO :"<<endl;
 	cin>>binario;
	 	
	for(int i=0;i<8;i++){
	    valor[i]=binario%10;
	    binario /=10;
	}
	
	for(int i=7;i>=0;i--){
	  result=(aux*2)+valor[i];
	  aux=result;
	}
	cout<<"\t\t\t\t\tEL NUMERO DECIMAL ES: "<<result<<endl;

 }

void menu(){
	int men;
	bool op1=false;

	do{
		system("cls");
			cout<<"\n\n----------------------------------------------------------------------------------------------------------------------"<<endl;
		cout<<"\n\t\t\t\t\t\t\t MENU\n"<<endl<<endl;
		cout<<"\t\t\t\t\t\t1) Decimal a Binario "<<endl;
		cout<<"\t\t\t\t\t\t2) Binario a Decimal "<<endl;
		cout<<"\t\t\t\t\t\t0) Salir "<<endl;
			cout<<"\n\n----------------------------------------------------------------------------------------------------------------------"<<endl;
		cin>>men;
		switch(men){
			case 1:
				system("cls");
		    	cout<<"\n\n\t\t\t\t\t CONVERTIDOR DECIMAL A BINARIO \n"<<endl<<endl;
				decimalB();
				system("pause");
			break;
				
			case 2:
				system("cls");
				cout<<"\n\n\t\t\t\t\t CONVERTIDOR BINARIO A  DECIMAL \n"<<endl<<endl; 
				binarioD();
				system("pause");
			break;
				
			case 0:
				cout<<"\n\n\n\t\t\t\tGRACIAS POR USAR EL PROGRAMA"<<endl;
				system("pause");
				exit(0);
			break;	
			
			default:
				cout<<"\n\n\n\n\t\t\t\t\tDIGITO UN VALOR INVALIDO INTENTELO DE NUEVO\n\n"<<endl;
			break;	
		}
		
	}while(op1!=true);

}

int main(){
	cout<<"\n\n----------------------------------------------------------------------------------------------------------------------"<<endl;
	cout<<"\n\n\t\t\t\t\t CONVERTIDOR DE BINARIO Y DECIMAL\n\n\n\n\t\t\t\t\t\t\t\t\t\t\t\tBy: Daniel Olarte"<<endl;
	cout<<"----------------------------------------------------------------------------------------------------------------------"<<endl;
	system("pause");
	system("cls");
	menu();
}
