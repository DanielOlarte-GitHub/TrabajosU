#include <iostream>
#include <fstream>

using namespace std;

string recibe;
ifstream archivo;

int main(){
	
	archivo.open("datos.txt");
	if(archivo.fail()){
		cout<<"Error en la apertura del archivo"<<endl;
		exit(0);
	}else{
		//mientras no sea el fin del archivo
		while(!archivo.eof()){
			archivo>>recibe;
			cout<<"El datos leido es: "<<recibe<<endl;
		}
	}
	
	archivo.close();
	
}
