#include <iostream>
#include <fstream>
using namespace std;


int salario;
string nombre, apellido;

ofstream archivo;



int main(){
	
	archivo.open("datos.txt"); //csv
	
	for(int i=1; i<=3; i++){
		
		system("cls");
		
		cout<<"Ingrese el nombre"<<endl;
		cin>>nombre;
		cout<<"Ingrese el apellido"<<endl;
		cin>>apellido;
		cout<<"Ingrese el salario"<<endl;
		cin>>salario;
		
		archivo << "\n" <<nombre << " " << apellido << " " << salario;	
		cout<<"Los datos han sido guardados"<<endl;
		
	}
	
	archivo.close();
	cout<<"Finalizo el programa"<<endl;
	
}
