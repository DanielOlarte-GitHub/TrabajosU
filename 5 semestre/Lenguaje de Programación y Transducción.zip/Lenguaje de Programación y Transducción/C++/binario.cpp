#include<iostream>
using namespace std;

void decimal_binario(){
	int binario[8];
	int decimal;
	cout<<"ingrese valor decimal"<<endl;
	cin>>decimal;
	
	for(int i=0;i<8;i++){
		binario[i]=decimal%2;
		decimal /=2;
		
	}
	//IMPRIME EL VALOR BINARIO DEL DECIMAL INGRESADO 
	cout<<"El numero  en binario es "<<endl;
	for(int i=7;i>=0;i--){
	  cout<<binario[i];
	}
	cout<<endl;
}
 
 
 void binario_decimal(){
 	int binario,result,resta=0;
 	int valor[8];
 	cout<<"ingrese valor binario :"<<endl;
 	cin>>binario;
	 	
	for(int i=0;i<8;i++){
	    valor[i]=binario%10;
	    binario /=10;
	}
	
	for(int i=7;i>=0;i--){
	  result=(resta*2)+valor[i];
	  resta=result;
	}
	cout<<"El numero decimal es : "<<result<<endl;

 }

void menu(){
	int men;
	bool op1=false;

	do{
		system("cls");
			
		cout<<"\n\n\t\t\t\t\t CONVERTIDOR DE BINARIO Y DECIMAL\n\n"<<endl<<endl;
		cout<<"1. Convertir de Decimal a binario "<<endl;
		cout<<"2. Convertir de Binario a Decimal "<<endl;
		cin>>men;
		switch(men){
			case 1:
				system("cls");
		    	cout<<" CONVERTIDOR   DECIMAL A BINARIO "<<endl<<endl;
				decimal_binario();
				system("pause");
			    break;
				case 2:
				system("cls");
				cout<<" CONVERTIDOR BINARIO A  DECIMAL "<<endl<<endl; 
				binario_decimal();
				system("pause");
				break;
		}
		
	}while(op1!=true);

}

int main(){
	menu();
}
