#include <iostream>
using namespace std;

int a[4]={5,6,7,8};
int*b;

int main(){
	b=a;
	for(int i=0, i<=3; i++){
		cout<<*b++<<endl;
	}
}
