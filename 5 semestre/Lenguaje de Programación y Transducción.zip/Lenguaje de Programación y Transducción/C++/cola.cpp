#include <iostream>
#include <queue>
using namespace std;

queue <int> cola;

int main(){
	
	cola.push(1);
	cola.push(2);
	cola.push(3);
	cola.push(4);
	cola.push(5);
	
	cout<<"El tama�o de la cola es: "<<cola.size()<<endl;
	cout<<"<0>: Con datos, <1> Sin datos El estado de la cola es: "<<cola.empty()<<endl;
	
	cout<<"El primer elemento de la cola es: "<<cola.front()<<endl;
	cout<<"El ultimo elemento de la cola es: "<<cola.back()<<endl;
	cola.pop();
	cout<<"\n--------------------------------\n"<<endl;
	cout<<"El primer elemento de la cola es: "<<cola.front()<<endl;
	cout<<"El ultimo elemento de la cola es: "<<cola.back()<<endl;
	
}
