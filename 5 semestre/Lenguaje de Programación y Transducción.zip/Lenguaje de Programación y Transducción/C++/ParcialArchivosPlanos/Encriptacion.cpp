#include <iostream>
#include <fstream>
#include <cstdlib> //convertir de char a entero


using namespace std;

bool bandera = true, bandera2 = true;
int men,cont=0, cont2 = 0, contPal = 0;
char usu[20], pass[20], recibe[40], palabras[20];
int recibeAux[40], palabrasAux[100], contadorCar=0;
ofstream archivoUC;
ofstream archivoPal;
ifstream archivoUC2;
ifstream archivoPal2;


//Metodo para mostrar las palabras
void mostrarP(){
	contPal=0;
	archivoPal2.open("palabras.txt");
	
	if(archivoPal2.fail()){
		cout<<"\n\n\t\t\t\t\t\tNO SE ENCUENTRA EL ARCHIVO archivoUC"<<endl;
		
	}else{
		
		cout<<"\n\n\t\t\t\t\tLISTA DE PALABRAS:\n\n"<<endl;
		
		cout<<"\t\t\t\t";
		//mientras no sea el fin del archivoUC
		while(!archivoPal2.eof()){
			
			archivoPal2>>palabras;
			palabrasAux[contPal] = atoi(palabras);
			
			if(palabrasAux[contPal]!='\0'){
				char caracter =palabrasAux[contPal]-6;
				cout<<caracter;
			}
			
			if(contPal==19 || contPal==39 || contPal==59 || contPal==79 || contPal==99){
				cout<<endl<<endl;
				cout<<"\t\t\t\t";
			}
			contPal++;
		
		}
	}
	archivoPal2.close();
	
}

//Metodo para guardar y encriptar las palabras
void capturarP(){
	archivoPal.open("palabras.txt");
	
	cout<<"\n\n\t\t\t\t\tCAPTURACION DE PALABRAS:"<<endl;
	
	for(int i =1; i<=5; i++){
		cout<<"\n\n\tDigite la palabra numero: "<<i<<" Debe tener minimo 5 caracteres\n";
		cin>>palabras;
		contadorCar = 0;
		for(int j=0; j<20; j++){
			if(palabras[j]!='\0'){
				contadorCar++;
			}
		}
		
		if(contadorCar>=5){
			for(int j=0; j<20; j++){
				archivoPal<<"\n"<<palabras[j]+6;
				palabras[j]='\0';
			}
		}else{
			cout<<"SU PALABRA TIENE MENOS DE 5 CARACTERES"<<endl<<endl;
			i--;
		}
		
		
	}
	archivoPal.close();
	cout<<endl<<endl;
	
}

//Segundo Menu para cuando ya entre con el usuario y contrase�a
void menu2(){
	system("cls");
	cout<<"\n\n\n\t\t\t\t\t\tMENU\n\n"<<endl;
	cout<<"\t\t\t1) Capturar palabras"<<endl;
	cout<<"\t\t\t2) Mostrar palabras"<<endl;
	cout<<"\t\t\t0) Salir"<<endl<<endl;
	cout<<"\t\t\tEscoja una opcion: ";
	cin>>men;
	
	switch(men){
		
		case 1:
			system("cls");
			capturarP();
			system("pause");
			menu2();
		break;
		
		case 2:
			system("cls");
			mostrarP();
			system("pause");
			menu2();
		break;
		
		
		case 0:
			system("cls");
			cout<<"\n\n\t\t\t\t\tREGRESANDO AL MENU PRINCIPAL"<<endl;
			
			
		break;
		
		default:
			system("cls");
			cout<<"\n\n\t\t\t\t\tDIGITO UNA OPCION INCORRECTA, INTENTELO DE NUEVO"<<endl;
			system("pause");
			menu2();
		break;	
	}
	
		
}

//Metodo para desencriptar y mostrar el usuario y contrase�a que estan encriptadas en el archivo
void mostrarDe(){
	
	archivoUC2.open("encriptacion.txt");
	
	if(archivoUC2.fail()){
		cout<<"\n\n\t\t\t\t\t\tNO SE ENCUENTRA EL ARCHIVO archivoUC "<<endl;
	}else{
		cont=0;
		cout<<"\n\n\t\t\t\t\tUSUARIO Y CONTRASE�A:\n\n"<<endl;
		
		cout<<"---------------------------------------------------\n"<<endl;
		cout<<"USUARIO:"<<endl;
		//mientras no sea el fin del archivoUC
		while(!archivoUC2.eof()){
			
			archivoUC2>>recibe;
			
			if(cont<20){
				recibeAux[cont] = atoi(recibe);
				char dS = recibeAux[cont]-152;
				
				cout<<dS;
			}
			
			
			cont++;
			
			
			if(cont>20){
				recibeAux[cont] = atoi(recibe);
				char dS = recibeAux[cont]-134;
				cout<<dS;
				cont2++;
			}
			
			if(cont==19){
				cout<<"\n\nCONTRASE�A:"<<endl;;
			}
		
		}
		cout<<endl;
	}
	archivoPal2.close();
	cout<<"\n---------------------------------------------------\n"<<endl;
	system("pause");
	system("cls");
}

//Metodo para ingresar el Usuario y Contrase�a
void ingresar(){
	
	cout<<"\n\n\t\t\t\t\tINGRESAR:"<<endl;
	
	archivoUC2.open("encriptacion.txt");
	
	cout<<"\n\n\t\t\tEscriba su Usuario: \n\t\t\t";
	cin>>usu;
	cout<<"\n\n\t\t\tEscriba su Password: \n\t\t\t";
	cin>>pass;
	
	
	if(archivoUC2.fail()){
		cout<<"\n\n\t\t\t\t\t\tNO SE ENCUENTRA EL ARCHIVO  archivoUC"<<endl;
	}else{
		
		//mientras no sea el fin del archivoUC
		while(!archivoUC2.eof()){
			
			
			archivoUC2>>recibe;
			
			if(cont<20){
				recibeAux[cont] = atoi(recibe);
				char dS = recibeAux[cont]-152;
				//cout<<usu[cont]<<"  |  "<<dS<<endl;
				
			
				if(dS!=usu[cont]){
					bandera = false;
				}
			}
			
			
			cont++;
			
			
			if(cont>20){
				recibeAux[cont] = atoi(recibe);
				char dS = recibeAux[cont]-134;
				//cout<<pass[cont2]<<"  |  "<<dS<<endl;
				if(dS != pass[cont2]){
					bandera2 =false;
				}
				cont2++;
			}
			
		}
	}
	archivoUC2.close();
	
	if(bandera==true && bandera2==true){
		system("cls");
		cout<<"\n\n\n\t\t\t\t\tBIENVENIDO"<<endl;
		system("pause");
		bandera=true;
		bandera2=true;
		menu2();
	}else{
		system("cls");
		bandera=true;
		bandera2=true;
		cout<<"\n\n\n\t\t\t\t\tDATOS INCORRECTOS"<<endl;
	}
	
}

//Metodo para encriptar el Usuario y Contrase�a anteriormente guardado
void encriptar(){
	
	archivoUC.open("encriptacion.txt");
	
	cout<<"\n\n\t\t\t\t\tENCRIPTACION:"<<endl;
	
	cout<<"\n\n\tUSUARIO: \n";
	system("pause");
	for(int i=0;i<20;i++){
		
		archivoUC<<"\n"<<usu[i]+152;
		cout<<usu[i]+152;
		
	}
		
	cout<<endl<<endl;
	archivoUC<<"\n";
		
	cout<<"\n\n\tPASSWORD: \n";
	system("pause");
	for(int i=0;i<20;i++){
		
		archivoUC<<"\n"<<pass[i]+134;
		cout<<pass[i]+134;
		
	}
	archivoUC.close();
	cout<<endl<<endl;
	
}

//Metodo para mostrar el Usuario y Contrase�a anteriormente guardados
void mostrar(){
	cout<<"\n\n\t\t\t\t\tDATOS\n\n"<<endl;
	cout<<"\tUSUARIO: ";
	for(int i=0; i<20; i++){
		if(usu[i]!='\0'){
			cout<<usu[i];
		}
		
	}
	cout<<endl<<endl;
	
	cout<<"\tPASSWORD: ";
	for(int i=0; i<20; i++){
		if(pass[i]!='\0'){
			cout<<pass[i];
		}
	}
	cout<<endl<<endl;
	
}

//Metodo para crear el Usuario y Contrase�a
void registrar(){
	cout<<"\n\n\t\t\t\t\tREGISTRAR USUARIO\n\n\n"<<endl;
	cout<<"\tIngrese el usuario"<<endl;
	cin>>usu;
	cout<<"Ingrese la contrase�a"<<endl;
	cin>>pass;
}

//Menu principal
void menu(){
	system("cls");
	cout<<"\n\n\n\t\t\t\t\t\tMENU\n\n"<<endl;
	cout<<"\t\t\t1) Registrar Usuario"<<endl;
	cout<<"\t\t\t2) Mostrar Datos del Usuario"<<endl;
	cout<<"\t\t\t3) Encriptar"<<endl;
	cout<<"\t\t\t4) Ingresar" <<endl;
	cout<<"\t\t\t5) Mostrar Datos del Usuario Ds"<<endl;
	cout<<"\t\t\t0) Salir"<<endl<<endl;
	cout<<"\t\t\tEscoja una opcion: ";
	cin>>men;
	
	switch(men){
		case 1:
			system("cls");
			registrar();
			system("pause");
		break;
		
		case 2:
			system("cls");
			mostrar();
			system("pause");
		break;
		
		case 3:
			system("cls");
			encriptar();
			system("pause");
		break;
		
		case 4:
			system("cls");
			ingresar();
			system("pause");
		break;
		
		case 5:
			system("cls");
			mostrarDe();
			system("pause");
		break;
		
		case 0:
			system("cls");
			cout<<"\n\n\t\t\t\t\tGRACIAS POR USAR EL PROGRAMA"<<endl;
			
			exit(0);
		break;
		
		default:
			system("cls");
			cout<<"\n\n\t\t\t\t\tDIGITO UNA OPCION INCORRECTA, INTENTELO DE NUEVO"<<endl;
			system("pause");
		break;	
	}
	menu();
}

//Metodo principal
int main(){
	cout<<"\n\n\t\t\t\t\tBIENVENIDO AL PROGRAMA DE ENCRIPTACION\n\t\t\t\t\t\t\tby:Daniel Olarte"<<endl<<endl;
	system("pause");
	system("cls");
	menu();
}


