#include <iostream>
using namespace std;

int pila[20]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
int pilaRepuesto[20]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
int persona=1, cant=0;

void cambiarElemento(){
	cout<<"\n\nESCRIBA EL ELEMENTO QUE QUIERA CAMBIAR ENTRE"<<1<<" - " <<cant<<endl;
	int camb;
	cin>>camb;
	
	cout<<"\n\nESCRIBA EL ELEMENTO QUE QUIERA POR EL QUE QUIERA CAMBIAR"<<endl;
	int cambio;
	cin>>cambio;
	
	for(int i=0; i<(sizeof(pila)/sizeof(*pila)); i++){
		if(pila[i]==camb){
			pila[i]=cambio;
		}else{
			int rep=0;
			pilaRepuesto[rep]=pila[i];
			rep++;
		}
	}
	
	
	
}

void mostrarCima(){
	for(int i=(sizeof(pila)/sizeof(*pila)); i>=0;i--){
		if(pila[i] != 0){
			cout<<"\nEL ELEMENTO DE LA CIMA ES: "<<pila[i]<<endl<<endl;
			break;
		}
	}
}

void mostrarPila(){
	for(int i=0; i<(sizeof(pila)/sizeof(*pila)); i++){
		if(pila[i]!=0){
			cout<<"   "<<pila[i]<<"   |   ";
		}
	}
	cout<<endl;
}

void tamano(){
	cout<<"EL TAMA�O DE LA PILA ES: "<<cant<<endl;
}


void retirarElemento(){
	for(int i=(sizeof(pila)/sizeof(*pila)); i>0;i--){
		if(pila[i] != 0){
			pila[i]=0;
			cant--;
			break;
		}
	}
	
}

void ingresarElemento(){
	for(int i=0; i<(sizeof(pila)/sizeof(*pila)); i++){
		if(pila[i]==0){
			pila[i]=persona;
			cout<<"\nSE HA AGREGADO EL ELEMENTO "<<persona<<" A LA PILA"<<endl;
			persona++;
			cant++;
			break;
		}
	}
	
}

void menu(){
	cout<<"\t\n\nMenu:\n\n1) Ingresar elemento a la pila (push)\n2) Retirar elemento de la pila (pop)\n3) Mostrar tama�o de la pila (size)\n4) Mostrar la cima de la pila (top)\n5) Cambiar elemento\n6) Mostrar Pila\n0) Salir"<<endl;
	int men;
	cin>>men;
	switch (men){
		case 1:
			ingresarElemento();
		break;
		
		case 2:
			retirarElemento();
		break;
		
		case 3:
			tamano();
		break;
		
		case 4:
			mostrarCima();
		break;
		
		case 5:
			cambiarElemento();
		break;
		
		case 6:
			mostrarPila();
		break;	
		
		case 0:
			cout<<"HA SELECCIONADO UNA OPCION INVALIDA INTENTELO DE NUEVO"<<endl;
		break;	
	}
	menu();
	
}

int main(){
	cout<<"\n\n\t\t\t\tBIENVENIDO AL EJERCICIO DE SIMULACION DE STACK\nby: Daniel Olarte\n\n"<<endl;
	system("pause");
	menu();
}
