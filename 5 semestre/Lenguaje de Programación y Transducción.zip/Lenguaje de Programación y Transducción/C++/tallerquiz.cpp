/*
	Estudiante Daniel Olarte �vila
	Lenguaje de programacion y transduccion
	Edgar Chamorro
	Programa de simulacion de personas de un transmilenio a una estacion o portal
*/

#include <iostream>
#include <stack>
#include <queue>
using namespace std;

//creando pilas y cola
queue <int> torniquete1;
queue <int> torniquete2;
stack <int> bus;
int personas=1;


void mostrarTorniquetes(){
	cout<<"\n\n\t\t\t\t\tESTADO DE LOS TORNIQUETES:\n"<<endl;
	//Torniquete 1
	if(torniquete1.empty()==1){
		cout<<"\n\n\t\t\t\tEL TORNIQUETE 1 ESTA VACIO\n"<<endl;
	}else{
		cout<<"\n\n\t\t\t\tEn el torniquete 1 hay una cantidad de: "<<torniquete1.size()<<" Personas\n\n"<<endl;
	}
	//Torniquete 2
	if(torniquete2.empty()==1){
		cout<<"\n\n\t\t\t\tEL TORNIQUETE 2 ESTA VACIO\n"<<endl;
	}else{
		cout<<"\n\n\t\t\t\tEn el torniquete 2 hay una cantidad de: "<<torniquete2.size()<<" Personas\n\n"<<endl;
	}
	system("pause");
	system("cls");
}

//Mostrar las personas en el bus
void mostrarBus(){
	if(bus.empty()==1){
		cout<<"\n\n\t\t\t\tEL BUS ESTA VACIO\n\n"<<endl;
	}else{
		cout<<"\n\n\t\t\t\tEn el bus hay una cantidad de: "<<bus.size()<<" Clientes\n\n"<<endl;
	}
	system("pause");
	system("cls");
}

//Retirar Personas del torniquete 2
void retirarTorniquete2(){
	if(torniquete2.empty()==0){
		torniquete2.pop();
		cout<<"\n\t\t\t\tPERSONA RETIRADA DEL TORNIQUETE 2\n\n"<<endl;
	}else{
		cout<<"\n\t\t\t\tNO HAY PERSONAS EN EL TORNIQUETE 2 PARA RETIRAR\n\n"<<endl;
	}
	system("pause");
	system("cls");
}

//Retirar Personas del torniquete 1
void retirarTorniquete1(){
	if(torniquete1.empty()==0){
		torniquete1.pop();
		cout<<"\n\t\t\t\tPERSONA RETIRADA DEL TORNIQUETE 1\n\n"<<endl;
	}else{
		cout<<"\n\t\t\t\tNO HAY PERSONAS EN EL TORNIQUETE 1 PARA RETIRAR\n\n"<<endl;
	}
	system("pause");
	system("cls");
}

//Menu para saber en que torniquete retirar la persona
void retirarDelTorniquete(){
	int menT;
	cout<<"\n\n\t\t\t\t\tRETIRAR PERSONA DEL TORNIQUETE MENU\nEn que torniquete le gustaria retirar 1 persona\n\t\t\t\t1) Torniquete 1\n\t\t\t\t2) Torniquete 2\n"<<endl;
	cin>>menT;
	switch(menT){
		case 1:
			retirarTorniquete1();
		break;
		
		case 2:
			retirarTorniquete2();
		break;
		
		default:
			cout<<"Escogio un valor invalido del menu\n"<<endl;
			retirarDelTorniquete();
		break;	
	}
	
}

//Agregar personas al torniquete
void personasTorniquete(){
	if(bus.empty()==0){
		if(torniquete1.size()<3){
			torniquete1.push(bus.top());
			bus.pop();
			cout<<"\nLa persona ha sido ingresada al torniquete 1\n\n"<<endl;
		}else if(torniquete2.size()<3){
			torniquete2.push(bus.top());
			bus.pop();
			cout<<"\nLa persona ha sido ingresada al torniquete 2\n\n"<<endl;
		}else{
			cout<<"\nLos torniquetes estan llenos"<<endl;
		}
	}else{
		cout<<"\nNO HAY PERSONAS EN EL BUS\n\n"<<endl;
	}
	system("pause");
	system("cls");
}

//Agregar 30 personas al bus
void personasAlBus(){
	for(int i=0;i<30;i++){
		bus.push(personas);
		personas++;
	}
}

//Menu principal
void menu(){
	cout<<"\n\t\t\t\t\t\tMenu:\n\t\t\t\t1) Llevar persona al torniquete\n\t\t\t\t2) Retirar persona del torniquete\n";
	cout<<"\t\t\t\t3) Mostrar Personas del bus\n\t\t\t\t4) Mostrar Clientes del torniquete\n\t\t\t\t5) Llenar otras 30 personas al bus"<<endl;
	cout<<"\t\t\t\t0) Salir\n"<<endl;
	int oMenu;
	cin>>oMenu;
	switch(oMenu){
		case 1:
			personasTorniquete();
		break;
		
		case 2:
			retirarDelTorniquete();
		break;
		
		case 3:
			mostrarBus();
		break;
		
		case 4:
			mostrarTorniquetes();
		break;
		
		case 5:
			cout<<"\n\t\t\t\tSE HAN AGREGADO 30 PERSONAS MAS AL BUS"<<endl;
			personasAlBus();
		break;
		
		case 0:
			cout<<"\n\t\t\t\tGRACIAS POR USAR EL PROGRAMA"<<endl;
			exit(0);
		break;
		
		default:
			cout<<"\n\t\t\t\tESCOGIO UNA OPCION INCORRECTA INTENTE DE NUEVO\n"<<endl;
			system("pause");
			system("cls");
		break;	
	}		
	menu();	
}

//Metodo principal del programa


int main(){
	cout<<"\n\n\t\t\t\t\tBIENVENIDO A EL CODIGO DE BUS TRANSMILENIO\n\t\t\t\t\t\t\tBy: Daniel Olarte"<<endl;
	system("pause");
	system("cls");
	personasAlBus();
	menu();	
}
