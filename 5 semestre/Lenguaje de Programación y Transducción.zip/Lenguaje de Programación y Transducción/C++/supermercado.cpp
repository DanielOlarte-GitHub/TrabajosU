#include <iostream>
#include <stack>
#include <queue>

using namespace std;
//cajas y cola
stack <int> caja1;
stack <int> caja2;
stack <int> caja3;
queue <int> fila;
int persona=0;

//retirar cliente de la caja 1
void retirarCaja1(){
	if(caja1.empty()==0){
		caja1.pop();
		cout<<"\n\tCLIENTE RETIRADO DE LA CAJA 1\n\n"<<endl;
	}else{
		cout<<"\nNO HAY CLIENTES EN LA CAJA 1 PARA RETIRAR\n\n"<<endl;
	}
}

//retirar cliente de la caja 2
void retirarCaja2(){
	if(caja2.empty()==0){
		caja2.pop();
		cout<<"\n\tCLIENTE RETIRADO DE LA CAJA 2\n\n"<<endl;
	}else{
		cout<<"\nNO HAY CLIENTES EN LA CAJA 2 PARA RETIRAR\n\n"<<endl;
	}
}

//retirar cliente de la caja 3
void retirarCaja3(){
	if(caja3.empty()==0){
		caja3.pop();
		cout<<"\n\tCLIENTE RETIRADO DE LA CAJA 3\n\n"<<endl;
	}else{
		cout<<"\nNO HAY CLIENTES EN LA CAJA 3 PARA RETIRAR\n\n"<<endl;
	}	
}

//Revisar si hay clientes o no en la fila
void estadoFila(){
	if(fila.empty()==1){
		cout<<"\n\nLA FILA ESTA VACIA\n\n"<<endl;
	}else{
		cout<<"\n\nEn la fila hay una cantidad de: "<<fila.size()<<" Clientes\n\n"<<endl;
	}
}

//Revisar si hay clientes o no en cada una de las cajas
void estadoCajas(){
	cout<<"\n\n\t\tESTADO DE CAJAS:\n"<<endl;
	//Caja 1
	if(caja1.empty()==1){
		cout<<"\n\nLA CAJA 1 ESTA VACIA\n"<<endl;
	}else{
		cout<<"\n\nEn la Caja 1 hay una cantidad de: "<<caja1.size()<<" Clientes\n\n"<<endl;
	}
	//Caja 2
	if(caja2.empty()==1){
		cout<<"\n\nLA CAJA 2 ESTA VACIA\n"<<endl;
	}else{
		cout<<"\n\nEn la Caja 2 hay una cantidad de: "<<caja2.size()<<" Clientes\n\n"<<endl;
	}
	//Caja 3
	if(caja3.empty()==1){
		cout<<"\n\nLA CAJA 3 ESTA VACIA\n\n"<<endl;
	}else{
		cout<<"\n\nEn la Caja 3 hay una cantidad de: "<<caja3.size()<<" Clientes\n\n"<<endl;
	}
}

//Mover el cliente que este en la fila, a una caja segun las reglas del ejercicio
//comprueba primero si hay clientes en la fila para poder hacer la funcion
void moverClienteaCaja(){
	if(fila.empty()==0){
		if(caja1.size()<3){
			caja1.push(fila.front());
			fila.pop();
			cout<<"\nEl cliente a ingresado a la caja 1\n\n"<<endl;
		}else if(caja2.size()<3){
			caja2.push(fila.front());
			fila.pop();
			cout<<"\nEl cliente a ingresado a la caja 2\n\n"<<endl;
		}else{
			caja3.push(fila.front());
			fila.pop();
			cout<<"\nEl cliente a ingresado a la caja 3\n\n"<<endl;
		}
	}else{
		cout<<"\nNO HAY CLIENTES EN LA FILA\n\n"<<endl;
	}
	
}

//menu para saber en que caja en especifico sacar el cliente
void retirarCajaMenu(){
	int menC;
	cout<<"\n\n\t\t\tRETIRAR CLIENTE DE CAJA MENU\nEn que caja le gustaria retirar 1 persona\n1) Caja 1\n2) Caja 2\n3) Caja 3"<<endl;
	cin>>menC;
	switch(menC){
		case 1:
			retirarCaja1();
		break;
		
		case 2:
			retirarCaja2();
		break;
		
		case 3:
			retirarCaja3();
		break;	
		
		default:
			cout<<"Escogio un valor invalido del menu\n"<<endl;
			retirarCajaMenu();
		break;	
	}
	
}

//Agregar personas a la fila
void agregarPersonas(){
	persona++;
	fila.push(persona);
	cout<<"\nSE HA INGRESADO UN CLIENTE A LA FILA\n\n"<<endl;
	cout<<"ACTUALMENTE HAY "<<persona<<" CLIENTES EN LA FILA\n\n"<<endl;
	
}

void limpiar(){
	system("cls");
}

//Menu principal
void menu(){
	int men;
	cout<<"ESCOJA UNA OPCION:\n1)Ingresar cliente a la fila\n2)Mover cliente a la caja\n3)Retirar Cliente de la caja\n4)Estado de la fila\n5)Estado de las cajas\n6)Limpiar Consola\n7)Salir"<<endl;
	cin>>men;
	switch(men){
		case 1:
			agregarPersonas();
		break;
		
		case 2:
			moverClienteaCaja();
		break;
		
		case 3:
			retirarCajaMenu();
		break;
		
		case 4:
			estadoFila();
		break;	
		
		case 5:
			estadoCajas();
		break;
		
		case 6:
			limpiar();
		break;	
		
		case 7:
			cout<<"\nGRACIAS POR USAR EL PROGRAMA"<<endl;
			exit(0);
		break;
		
		default:
			cout<<"\nESCOGIO UNA OPCION INVALIDA, INTENTE DE NUEVO\n"<<endl;
		break;	
			
	}
	menu();
}

//Main
int main(){
	cout<<"\t\t\t\t\tBIENVENIDO AL PROGRAMA DE SUPER MERCADO\n\t\t\t\t\t\tby:Daniel Olarte\n\n"<<endl;
	menu();
	
}



