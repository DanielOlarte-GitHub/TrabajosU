#include <iostream>
using namespace std;

struct personas{
	int id;
	string nom;
	string ape;
	int edad;
};

personas personas1[5];

int main(){
	
	for(int i = 0; i<5; i++){
		
		cout<<"Ingrese su identificacion"<<endl;
		cin>>personas1[i].id;
		cout<<"Ingrese su nombre"<<endl;
		cin>>personas1[i].nom;
		cout<<"Ingrese su apellido"<<endl;
		cin>>personas1[i].ape;
		cout<<"Ingrese su edad"<<endl;
		cin>>personas1[i].edad;
	}
	
	
}
