#include <iostream>
using namespace std;

int op; //variable de la opcion

string codest,codmat; //variable para la busqueda de estudiante y la materia

bool seguir=true, existee=false, existem=false; // variables para controlar seguir en el menu y validar si existe el alumno y la materia

//estructura alumnos
struct alumnos{
      int idalu;
	  string nomalu;
	  string apealu;
};

//estructura materia
struct materia{
      int idalu;
	  string nommat;
};

//variables tipo estructura para alumnos y materias

alumnos estudiantes;
materia materia;
//matriz para estudiantes y materias

string estudiantes1[3][3];
string materias[4][2];

//validar si existe estudiante y si existe la materia
void validare(string codigo)
{
	system("cls");
	for (int a=0; a<=2;a++)
	{
		
		if (codigo==estudiantes1[a][0])
		{
			existee=true;
		}
		
	}
	
	if (existee==true)
	{
      cout<<"Ingrese codigo de la materia "<<endl;
      cin>>codmat;
      
		for (int c=0; c<=3;c++)
		{
			if (codmat==materias[c][0])
			{
				existem=true;
			}
				
		}
   }
}

void mensaje()
{
	system("cls");
	cout<<"No encontro los datos, para continuar con el proceso. Verifique los Datos"<<endl;
	system("pause");   	
}

int main()
{	 
     do{
	       system("cls");
     	   cout<<"  Menu Principal   "<<endl;
     	   cout<<"1. Ingresar Alumnos "<<endl;
     	   cout<<"2. Ingresar Materias"<<endl;
     	   cout<<"3. Ingresar Materia a un estudiante"<<endl;
     	   cout<<"4. Ingresar Notas a un estudiante"<<endl;
     	   cout<<"Ingresar opcion"<<endl;
		   cin>>op;
           switch(op){
           case 1:
           		       system("cls");
					   for (int a=0; a<=2;a++)
           		       {
           		       	  for (int b=0; b<=2;b++){
	           		     	cout<<"Ingrese el codigo del estudiante "<<"["<<a+1<<"]";
             		    	cin>>estudiantes1[a][b];
           		     	       
							}
					  	}
						cout<<"Estudiantes ingresados correctamente"<<endl;
						system("pause"); 
           		     break;
           	case 2:
           		    system("cls");
					for (int e=0; e<=3;e++)
           		      {
           		      for (int f=0; f<=1;f++){
           		    	   
	           			   	cout<<"Ingrese el codigo de la materia "<<"["<<e+1<<"]";
             			 	cin>>materias[e][f];
           		        }
           		    }
           		    break;
           	case 3:
           		    system("cls");
					cout<<"Ingrese codigo del estudiante "<<endl;
           		    cin>>codest;
           		    validare(codest);
           		    if (existem==true)
           		       {
           		        system("cls");
						cout<<"Encontro los datos, puedo continuar con el proceso"<<endl;
						system("pause");       	
					   }
					else
					{
					   mensaje();    	
					}   
           		    
           		    break;
           	case 4://///////////////////////////////////////
           		    break;
							   } 		    	 
	 }while (seguir==true);
	  
}

